# Validation record — mergekit-source 0.3.0

Environment: Linux AMD64, Python 3.13.5, Node.js 22.16.0, Git; globally installed TypeScript and PostCSS.

## Executed checks

- `python -m pytest -q --disable-warnings --maxfail=1` — **60 passed**.
- `python -m compileall -q mergekit tests benchmarks` — passed.
- `node --check mergekit/parse_node.cjs` — passed.
- Node bridge batch smoke test: one JavaScript snapshot and one CSS snapshot in one process — both valid.
- Repeated editor snapshot checks: immutable snapshot cache, guarded function-body partial parse, Unicode offsets, full-parse fallback, Node batching, cache bounds and reused metrics.
- Mutations tested: Python imports, annotations, typed final-class assignments, local and declaration renames, moved/extracted statements, independent AST expression branches, JS function-to-arrow transformation, HTML elements/attributes, CSS selector/custom-property rename, conflict detection, and 5-second delta policy.

## Benchmark

`python -m benchmarks.benchmark_merger`

Illustrative local output, end-to-end pipeline including parsing, reconciliation and syntax validation:

| Python functions | Cold | Warm editor update |
|---|---:|---:|
| 100 | 0.035 s | 0.073 s |
| 1,000 | 0.373 s | 0.173 s |
| 5,000 | 2.402 s | 1.076 s |

Benchmark workload: one user-edited return expression and tool-added parameter/return annotations on all functions. Cache persists between edits. This is **not an end-to-end latency guarantee** on arbitrary real code, slow disks, or large paste events. The parser/matcher takes the conservative full path when structural identity cannot be proved.

## Fallow plugin status

Read the installed Fallow and Fallow Review plugin skills. Fallow's analysis CLI is **not installed in the execution environment**. Its offline npm package is also not cached (`ENOTCACHED`), so no Fallow audit report was produced. Do **not** treat the Node syntax and batch tests as a substitute for Fallow's graph analysis, duplication analysis, or complexity/architecture assessment. The relevant JavaScript/TypeScript surface is `mergekit/parse_node.cjs`.

## Validation not completed

- Fallow codebase analysis — executable unavailable (above).
- Ruff and BasedPyright — system tools and the optional self-contained `linters-linux-amd64.zip` were not found in the accessible toolchain/Library lookup. The canonical `rules.zip` was retrieved and consulted, but zero-issue rule compliance is **not** certified.
- Cross-file or compiler-assisted symbol resolution and semantic-equivalence proofs.
- Full AST incremental parsing for JavaScript, CSS, HTML, or Python edits that cross scope boundaries.
- Production editor compare-and-swap write integration, filesystem races, large-scale randomized mutation fuzzing, and cross-platform execution.
- Coverage threshold — deferred by request.

The merger returns `source=None` on recognized merge conflicts and does not itself write files. Novel ambiguous transformations can still exist outside the supported matching grammar; maintain independent project validation before committing merged results.
