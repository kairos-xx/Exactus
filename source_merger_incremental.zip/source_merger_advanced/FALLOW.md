# Fallow analysis status

The Fallow plugin's instructions were loaded and followed for scoping.

The relevant JavaScript file is `mergekit/parse_node.cjs`. The requested CLI audit could not run because Fallow is not installed and the package is not cached offline. The canonical invocation for a machine-readable scan, once the executable is available, is:

```sh
fallow health --file-scores --format json --quiet --explain 2>/dev/null || true
fallow dupes --format json --quiet --explain 2>/dev/null || true
fallow dead-code --format json --quiet --explain 2>/dev/null || true
```

The executable will need to be installed in the user's environment before these commands can produce findings; no install or telemetry setting was changed here.

Executed substitute checks: `node --check mergekit/parse_node.cjs` and a batch parsing smoke test. These check syntax and parser operation only, not the static analysis Fallow would report.
