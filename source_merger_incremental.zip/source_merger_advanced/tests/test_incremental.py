"""Regression cases for hierarchical incremental source reconciliation."""

from __future__ import annotations

import ast

import pytest

from mergekit import SnapshotCache, SourceMerger, measure
from mergekit.cache import StatementIndex
from mergekit.model import MergeResult, Replacement, Snapshot, Statement
from mergekit.patch import apply
from mergekit.python_parser import PythonParser


def test_reparse_isolated_function_matches_full_parse() -> None:
    """Reuse surrounding units and shift all offsets after one edited function."""
    ancestor: str = (
        "def f(x):\n    return x + 1\n\n"
        "def g(x):\n    return x * 9\n"
    )
    edited: str = ancestor.replace("return x + 1", "return x + 200")
    cache: SnapshotCache = SnapshotCache()
    cache.parse_forks(original=ancestor, user=ancestor, tool=ancestor, language="python")
    next_version: tuple[Snapshot, Snapshot, Snapshot] = cache.parse_forks(
        original=ancestor, user=edited, tool=ancestor, language="python",
    )
    assert next_version[1] == PythonParser().parse(source=edited)
    assert cache.stats.incremental == 1
    assert cache.stats.parsed == 2


def test_incremental_handles_unicode_offsets() -> None:
    """Python's byte-indexed AST columns remain correct after Unicode edits."""
    original: str = 'def f(x):\n    return "café" + x\n\ndef g(y):\n    return y\n'
    edited: str = original.replace('"café" + x', '"café é" + x')
    cache: SnapshotCache = SnapshotCache()
    cache.parse_forks(original=original, user=original, tool=original, language="python")
    result: tuple[Snapshot, Snapshot, Snapshot] = cache.parse_forks(
        original=original, user=edited, tool=original, language="python"
    )
    assert result[1] == PythonParser().parse(source=edited)
    assert cache.stats.incremental == 1


def test_incremental_falls_back_on_function_rename() -> None:
    """A signature or declaration identity change must get a full parse."""
    old: str = "def f(x):\n    return x\n"
    changed: str = "def renamed(x):\n    return x\n"
    cache: SnapshotCache = SnapshotCache()
    cache.parse_forks(original=old, user=old, tool=old, language="python")
    result: tuple[Snapshot, Snapshot, Snapshot] = cache.parse_forks(
        original=old, user=changed, tool=old, language="python"
    )
    assert result[1] == PythonParser().parse(source=changed)
    assert cache.stats.incremental == 0


def test_incremental_falls_back_on_new_top_level_declaration() -> None:
    """Appending a new declaration must not be misclassified as a body edit."""
    old: str = "def f(x):\n    return x\n"
    changed: str = old + "\ndef g(x):\n    return x\n"
    cache: SnapshotCache = SnapshotCache()
    cache.parse_forks(original=old, user=old, tool=old, language="python")
    result: tuple[Snapshot, Snapshot, Snapshot] = cache.parse_forks(
        original=old, user=changed, tool=old, language="python"
    )
    assert result[1] == PythonParser().parse(source=changed)
    assert len(result[1].units) == 2
    assert cache.stats.incremental == 0


def test_parse_cache_batches_foreign_snapshots() -> None:
    """JavaScript parser starts only one process for three fork snapshots."""
    cache: SnapshotCache = SnapshotCache()
    snapshots: tuple[Snapshot, ...] = cache.parse_many(
        sources=("function f(x) {return x;}", "const f = (x) => x;", "const g = (x) => x;"),
        language="javascript",
    )
    assert all(snapshot.valid for snapshot in snapshots)
    assert cache.stats.batches == 1
    assert cache.stats.parsed == 3
    cache.parse_many(
        sources=("function f(x) {return x;}", "const f = (x) => x;", "const g = (x) => x;"),
        language="javascript",
    )
    assert cache.stats.batches == 1
    assert cache.stats.reused == 3


def test_cache_is_bounded() -> None:
    """Previous editor snapshots cannot grow session memory without limits."""
    cache: SnapshotCache = SnapshotCache(max_snapshots=2, max_matches=1)
    for source in ("x = 1\n", "x = 2\n", "x = 3\n"):
        assert cache.parse(source=source, language="python").valid
    assert cache.stats.parsed == 3
    assert cache.parse(source="x = 1\n", language="python").valid
    assert cache.stats.parsed == 4


@pytest.mark.parametrize(
    ("original", "user", "tool", "expected"),
    [
        (
            "def f(x):\n    return calculate(x, 1)\n",
            "def f(x):\n    return calculate(x, 2)\n",
            "def f(x):\n    return calculate(x + 3, 1)\n",
            "calculate(x + 3, 2)",
        ),
        (
            "def f(x):\n    return (x + 1) * (x + 2)\n",
            "def f(x):\n    return (x + 3) * (x + 2)\n",
            "def f(x):\n    return (x + 1) * (x + 4)\n",
            "(x + 3) * (x + 4)",
        ),
        (
            "def f(x):\n    return calculate(x, 1)\n",
            "def f(x):\n    return calculate(x, 2)\n",
            "def f(x):\n    return prepare(x)\n\ndef prepare(x):\n    return calculate(x+3,1)\n",
            "calculate(x+3,2)",
        ),
        (
            "VALUE = merge(x,1)\n",
            "VALUE = merge(x,2)\n",
            "from typing import Final, final\n@final\nclass Constants:\n    VALUE: Final[int] = merge(x+1,1)\n",
            "VALUE: Final[int] = merge(x+1,2)",
        ),
    ],
)
def test_independent_expression_mutations(
    *, original: str, user: str, tool: str, expected: str
) -> None:
    """Project changed expression leaves through independent refactoring."""
    result: MergeResult = SourceMerger(
        original=original, user_edited=user, tool_refactored=tool,
        language="python",
    ).merge()
    assert result.success, result.conflicts
    assert result.source is not None
    assert expected in result.source
    ast.parse(source=result.source)


def test_competing_expression_edits_fail_closed() -> None:
    """Both forks changing the same literal must not pick a winner."""
    result: MergeResult = SourceMerger(
        original="def f(x):\n    return x + 1\n",
        user_edited="def f(x):\n    return x + 2\n",
        tool_refactored="def f(x):\n    return x + 3\n",
        language="python",
    ).merge()
    assert not result.success
    assert result.source is None
    assert any(conflict.kind == "concurrent_change" for conflict in result.conflicts)


def test_repeated_merges_share_immutable_cache() -> None:
    """Consecutive editor events reuse ancestor and prior fork without leakage."""
    cache: SnapshotCache = SnapshotCache()
    ancestor: str = "def f(x):\n    return x + 1\n\ndef stable(x):\n    return x\n"
    tool: str = "def f(x: int) -> int:\n    return x + 1\n\ndef stable(x: int) -> int:\n    return x\n"
    for value in (2, 3, 4):
        user: str = ancestor.replace("return x + 1", f"return x + {value}")
        result: MergeResult = SourceMerger(
            original=ancestor, user_edited=user, tool_refactored=tool,
            language="python", snapshot_cache=cache,
        ).merge()
        assert result.success, result.conflicts
        assert result.source is not None
        assert f"return x + {value}" in result.source
    assert cache.stats.incremental >= 2
    assert cache.stats.reused >= 2


def test_index_rejects_ambiguous_duplicate_statements() -> None:
    """Equivalent statements in independent scopes cannot be guessed."""
    snapshot: Snapshot = PythonParser().parse(
        source="def f():\n    return 1\n\ndef g():\n    return 1\n"
    )
    index: StatementIndex = StatementIndex(snapshot=snapshot)
    statement: Statement = snapshot.units[0].statements[0]
    assert index.locate(original=statement, preferred=None) is None
    assert index.locate(original=statement, preferred=snapshot.units[0]) == statement


def test_atomic_patch_reconstruction_preserves_insert_order() -> None:
    """Linear source reconstruction matches prior same-position insert semantics."""
    assert apply(source="abcd", replacements=(
        Replacement(2, 2, "X", "first"),
        Replacement(2, 2, "Y", "second"),
    )) == "abYXcd"
    with pytest.raises(ValueError, match="Overlapping"):
        apply(source="abcdef", replacements=(
            Replacement(2, 4, "X", "first"),
            Replacement(3, 5, "Y", "second"),
        ))


def test_large_delta_detects_user_paste() -> None:
    """Line-anchored diff still counts substantial pasted text accurately."""
    ancestor: str = "\n".join(f"def f{i}(x): return {i}" for i in range(200))
    pasted: str = ancestor + "\n" + "\n".join(f"def added{i}(): return {i}" for i in range(300))
    result = measure(original=ancestor, changed=pasted, language="python")
    assert result.inserted_tokens > 1000
    assert result.edit_events > 0


def test_identity_confidence_threshold_is_active() -> None:
    """A strict policy must reject otherwise plausible renamed declarations."""
    from mergekit import DeltaPolicy

    original: str = "def f(x):\n    return x + 1\n"
    result: MergeResult = SourceMerger(
        original=original,
        user_edited="def f(x):\n    return x + 2\n",
        tool_refactored="def g(x):\n    return x + 1\n",
        language="python",
        delta_policy=DeltaPolicy(min_identity_confidence=0.999),
    ).merge()
    assert not result.success
    assert result.source is None


def test_cache_reuses_identical_delta_reports() -> None:
    """Repeated tool fork metrics are not recomputed for each editor event."""
    cache: SnapshotCache = SnapshotCache()
    original: str = "def f(x):\n    return x + 1\n"
    tool: str = "def f(x: int) -> int:\n    return x + 1\n"
    for value in (2, 3):
        assert SourceMerger(
            original=original,
            user_edited=original.replace("x + 1", f"x + {value}"),
            tool_refactored=tool, language="python", snapshot_cache=cache,
        ).merge().success
    assert cache.stats.reused_deltas >= 1


def test_indentation_only_semantic_change_consumes_delta() -> None:
    """Equal tokens cannot make indentation-only semantic changes free."""
    original: str = (
        "def f(x):\n    if x:\n        print(x)\n"
        "    print('always')\n"
    )
    changed: str = original.replace(
        "    print('always')", "        print('always')"
    )
    report = measure(original=original, changed=changed, language="python")
    assert report.changed_fraction > 0
    assert report.replaced_tokens > 0


def test_assignment_preserves_tool_side_variable_edit() -> None:
    """A name-insensitive fingerprint must not erase another RHS change."""
    result: MergeResult = SourceMerger(
        original="VALUE = x + 1\n",
        user_edited="VALUE = x + 2\n",
        tool_refactored="VALUE: int = y + 1\n",
        language="python",
    ).merge()
    assert result.success, result.conflicts
    assert result.source is not None
    assert "VALUE: int = y + 2" in result.source


def test_assignment_rejects_same_leaf_parallel_edits() -> None:
    """Concurrent assignment changes to the same literal never auto-merge."""
    result: MergeResult = SourceMerger(
        original="VALUE = x + 1\n",
        user_edited="VALUE = x + 2\n",
        tool_refactored="VALUE: int = x + 3\n",
        language="python",
    ).merge()
    assert not result.success
    assert result.source is None
