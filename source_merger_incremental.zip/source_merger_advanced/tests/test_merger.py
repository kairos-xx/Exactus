"""Regression tests for identity-preserving source mutation reconciliation."""

from __future__ import annotations

import ast

import pytest

from mergekit import MergeResult, SourceMerger
from mergekit.model import Language


def reconcile(*, language: Language, original: str, user: str, tool: str) -> MergeResult:
    """Merge three source versions using the public Python API.

    Args:
        language: Parser language.
        original: Common ancestor.
        user: User-edited fork.
        tool: Tool-refactored fork.

    Returns:
        Merge result with explicit conflict reporting.
    """
    return SourceMerger(
        original=original, user_edited=user, tool_refactored=tool,
        language=language,
    ).merge()


@pytest.mark.parametrize(
    ("original", "user", "tool", "required"),
    [
        (
            "def f(x):\n    return x + 1\n",
            "def f(x):\n    if x < 0:\n        raise ValueError('negative')\n    return x + 1\n",
            "def f(x: int) -> int:\n    return x + 1\n",
            ("x: int", "if x < 0", "raise ValueError"),
        ),
        (
            "def process(value):\n    return value + 1\n",
            "def process(value):\n    if value < 0:\n        raise ValueError('negative')\n    return value + 1\n",
            "def calculate(number: int) -> int:\n    return number + 1\n",
            ("def calculate", "if number < 0", "return number + 1"),
        ),
        (
            "def f(x):\n    result = x + 1\n    return result\n",
            "def f(x):\n    result = x + 2\n    return result\n",
            "def f(x: int) -> int:\n    total: int = x + 1\n    return total\n",
            ("total: int = x + 2", "return total"),
        ),
        (
            "LIMIT = 5\n",
            "LIMIT = 7\n",
            "from typing import Final, final\n@final\nclass Constants:\n    LIMIT: Final[int] = 5\n",
            ("@final", "class Constants", "LIMIT: Final[int] = 7"),
        ),
        (
            "class C:\n    def first(self):\n        return 1\n\n    def second(self):\n        return 2\n",
            "class C:\n    def first(self):\n        return 9\n\n    def second(self):\n        return 2\n",
            "class C:\n    def second(self):\n        return 2\n\n    def first(self):\n        return 1\n",
            ("def second", "return 9", "def first"),
        ),
        (
            "def f(x):\n    validate(x)\n    transform(x)\n    save(x)\n",
            "def f(x):\n    validate(x)\n    transform(x, strict=True)\n    save(x)\n",
            "def f(x):\n    prepare(x)\n    save(x)\n\ndef prepare(x):\n    validate(x)\n    transform(x)\n",
            ("def prepare", "transform(x, strict=True)", "save(x)"),
        ),
        (
            "def f(x):\n    return x\n",
            "def f(x):\n    return x + 2\n",
            "def f(x: int) -> int:\n    return x\n\ndef extra():\n    return 0\n",
            ("return x + 2", "def extra"),
        ),
    ],
)
def test_python_refactoring(*, original: str, user: str, tool: str, required: tuple[str, ...]) -> None:
    """Ensure typing, movements and new declarations preserve user mutations."""
    result: MergeResult = reconcile(language="python", original=original, user=user, tool=tool)
    assert result.success, result.conflicts
    assert result.source is not None
    ast.parse(source=result.source)
    assert all(part in result.source for part in required)
    if "def second" in result.source:
        assert result.source.index("def second") < result.source.index("def first")
    if "def prepare" in result.source:
        assert result.source.index("save(x)") < result.source.index("def prepare")


@pytest.mark.parametrize(
    ("language", "original", "user", "tool", "required"),
    [
        (
            "javascript", "function f(x) {\n  return x + 1;\n}\n",
            "function f(x) {\n  if (x < 0) throw Error('negative');\n  return x + 1;\n}\n",
            "const f = (value) => value + 1;\n",
            ("const f", "=> {", "if (value < 0)", "return value + 1"),
        ),
        (
            "javascript", "function compute(x) {\n  return x + 1;\n}\n",
            "function compute(x) {\n  return x + 2;\n}\n",
            "const calculate = (value) => value + 1;\n",
            ("const calculate", "value + 2"),
        ),
        (
            "javascript", "function say(x) {\n  return x + 1;\n}\n",
            "function say(x) {\n  console.log('x');\n  return x + 1;\n}\n",
            "const say = (value) => value + 1;\n",
            ("console.log('x')", "value + 1"),
        ),
        (
            "typescript", "function f(x) {\n  return x + 1;\n}\n",
            "function f(x) {\n  if (x < 0) throw Error('bad');\n  return x + 1;\n}\n",
            "const f = (x: number): number => x + 1;\n",
            ("x: number", "if (x < 0)"),
        ),
        (
            "css", ".old { color: red; }\n",
            ".old { color: blue; }\n",
            ".new { color: red; }\n",
            (".new", "color: blue"),
        ),
        (
            "css", ".x { --old: red; }\n",
            ".x { --old: blue; }\n",
            ".x { --new: red; }\n",
            ("--new: blue",),
        ),
        (
            "css", ".a { color: red; }\n.b { opacity: 1; }\n",
            ".a { color: blue; }\n.b { opacity: 1; }\n",
            ".b { opacity: 1; }\n.a { color: red; }\n",
            ("color: blue", "opacity: 1"),
        ),
        (
            "html", '<div id="a"><span>One</span></div>\n',
            '<div id="a"><span>Two</span></div>\n',
            '<main><div id="a"><span>One</span></div></main>\n',
            ("<main>", "<span>Two</span>"),
        ),
        (
            "html", '<div id="hero" class="old"><span>Hello</span></div>\n',
            '<div id="hero" class="new"><span>Welcome</span></div>\n',
            '<main><div data-x="1" id="hero" class="old"><span>Hello</span></div></main>\n',
            ('class="new"', 'data-x="1"', "Welcome"),
        ),
        (
            "html", '<div id="outer"><b id="inner">A</b></div>\n',
            '<div id="outer"><b id="inner">B</b></div>\n',
            '<section><div id="outer"><b id="inner">A</b></div></section>\n',
            ("<section>", "<b id=\"inner\">B</b>"),
        ),
    ],
)
def test_other_languages(
    *, language: Language, original: str, user: str, tool: str, required: tuple[str, ...]
) -> None:
    """Merge JavaScript arrow conversion, CSS relocation, and HTML movement."""
    result: MergeResult = reconcile(language=language, original=original, user=user, tool=tool)
    assert result.success, result.conflicts
    assert result.source is not None
    assert all(part in result.source for part in required)


@pytest.mark.parametrize(
    ("language", "original", "user", "tool", "kind"),
    [
        (
            "python", "def f(x):\n    return x\n",
            "def f(x):\n    return x\n\nprint(f(3))\n",
            "def g(x):\n    return x\n",
            "unsupported_transformation",
        ),
        (
            "python", "def f(x):\n    return x\n",
            "def f(x: str):\n    return x\n",
            "def f(x: int):\n    return x\n",
            "unsupported_transformation",
        ),
        (
            "python", "def f(x):\n    return x\n",
            "def f(y):\n    return y\n",
            "def f(x: int):\n    return x\n",
            "unsupported_transformation",
        ),
        (
            "python", "X = 1\n",
            "X = 2\n",
            "X = 3\n",
            "concurrent_change",
        ),
        (
            "python", "def f(x):\n    return x\n",
            "def f(x):\n    # User note\n    return x\n",
            "def f(x: int):\n    return x\n",
            "unsupported_transformation",
        ),
        (
            "javascript", "function f(x) { return x; }\n",
            "function f(y) { return y; }\n",
            "const f = (x) => x;\n",
            "unsupported_transformation",
        ),
        (
            "html", '<div id="a" class="old">A</div>\n',
            '<div id="a" class="user">A</div>\n',
            '<div id="a" class="tool">A</div>\n',
            "concurrent_change",
        ),
        (
            "html", '<div id="a">A</div>\n',
            '<div id="a">B</div>\n',
            '<div id="a"><b>A</b></div>\n',
            "textual_conflict",
        ),
        (
            "css", '.a { color: red; }\n',
            '.a { color: blue; }\n',
            '.a { color: green; }\n',
            "missing_anchor",
        ),
    ],
)
def test_conflicts(
    *, language: Language, original: str, user: str, tool: str, kind: str,
) -> None:
    """Reject unsupported or incompatible changes without an output file."""
    result: MergeResult = reconcile(language=language, original=original, user=user, tool=tool)
    assert not result.success
    assert result.source is None
    assert any(item.kind == kind for item in result.conflicts), result.conflicts


def test_no_op_returns_tool() -> None:
    """Return the untouched tool fork when no user edits occurred."""
    result: MergeResult = reconcile(
        language="python", original="x = 1\n", user="x = 1\n", tool="x: int = 1\n",
    )
    assert result.success and result.source == "x: int = 1\n"


def test_no_tool_edits_returns_user() -> None:
    """Return current user source when the tool made no changes."""
    result: MergeResult = reconcile(
        language="python", original="x = 1\n", user="x = 2\n", tool="x = 1\n",
    )
    assert result.success and result.source == "x = 2\n"


def test_invalid_python_fails_closed() -> None:
    """Reject a syntactically incomplete original ancestor."""
    result: MergeResult = reconcile(
        language="python", original="def x(: pass", user="def x(: return 1", tool="def y(: pass",
    )
    assert not result.success and result.source is None
    assert any(item.kind == "parse_error" for item in result.conflicts)


def test_python_wrapping_survives_literal_change() -> None:
    """Keep refactor-generated multiline formatting around an edited literal."""
    result: MergeResult = reconcile(
        language="python",
        original="def f(x):\n    return sum([1, 2]) + x\n",
        user="def f(x):\n    return sum([1, 3]) + x\n",
        tool=(
            "def f(x: int) -> int:\n    return (\n        sum(\n            [\n"
            "                1,\n                2,\n            ]\n"
            "        ) + x\n    )\n"
        ),
    )
    assert result.success and result.source is not None
    assert "                3," in result.source
    assert "    return (\n" in result.source


def test_python_new_import_survives_tool_import_regrouping() -> None:
    """Preserve user import additions alongside tool import consolidation."""
    result: MergeResult = reconcile(
        language="python",
        original="from typing import Optional\n\ndef f(x):\n    return x + 1\n",
        user=(
            "from pathlib import Path\nfrom typing import Optional\n\n"
            "def f(x):\n    return x + 2\n"
        ),
        tool=(
            "from typing import Final, Optional\n\n"
            "def f(x: int) -> int:\n    return x + 1\n"
        ),
    )
    assert result.success and result.source is not None
    assert "from pathlib import Path" in result.source
    assert "from typing import Final, Optional" in result.source
    assert "return x + 2" in result.source


def test_css_property_reference_tracks_renaming() -> None:
    """Move newly inserted custom-property references to their tool-side name."""
    result: MergeResult = reconcile(
        language="css",
        original=".x {\n  --old: red;\n}\n",
        user=".x {\n  --old: red;\n  color: var(--old);\n}\n",
        tool=".x {\n  --new: red;\n}\n",
    )
    assert result.success and result.source is not None
    assert "  color: var(--new);\n}" in result.source


def test_html_independent_attribute_addition() -> None:
    """Retain two independently added attributes during HTML relocation."""
    result: MergeResult = reconcile(
        language="html",
        original='<div id="hero">Hi</div>\n',
        user='<div id="hero" title="Hello">Hi</div>\n',
        tool='<main><div id="hero" data-x="1">Hi</div></main>\n',
    )
    assert result.success and result.source is not None
    assert 'data-x="1"' in result.source and 'title="Hello"' in result.source


def test_js_regex_is_not_rewritten_during_parameter_rename() -> None:
    """Rename identifiers inside calls without editing regexp literal contents."""
    result: MergeResult = reconcile(
        language="javascript",
        original="function f(x) {\n  return x;\n}\n",
        user="function f(x) {\n  if (/x/.test(x)) throw Error('bad');\n  return x;\n}\n",
        tool="const f = (value) => value;\n",
    )
    assert result.success and result.source is not None
    assert "/x/.test(value)" in result.source


def test_user_import_removal_that_tool_retains_is_conflict() -> None:
    """Reject removing tool-required imports without reference analysis."""
    result: MergeResult = reconcile(
        language="python",
        original="import os\nimport sys\n\nx = 1\n",
        user="import os\n\nx = 2\n",
        tool="import sys\nimport os\n\nx: int = 1\n",
    )
    assert not result.success and result.source is None
    assert any(item.scope == "imports" for item in result.conflicts)


def test_css_single_line_without_trailing_newline() -> None:
    """Never let PostCSS offset conventions overrun a closing brace."""
    result: MergeResult = reconcile(
        language="css",
        original=".a { color: red; }",
        user=".a { color: blue; }",
        tool=".b { color: red; }",
    )
    assert result.success and result.source is not None
    assert ".b" in result.source and "color: blue" in result.source


def test_python_function_moved_into_final_class() -> None:
    """Track a function converted into a static method in a generated class."""
    result: MergeResult = reconcile(
        language="python",
        original="def f(x):\n    return x + 1\n",
        user="def f(x):\n    return x + 2\n",
        tool=(
            "from typing import final\n@final\nclass Operations:\n"
            "    @staticmethod\n    def f(x: int) -> int:\n        return x + 1\n"
        ),
    )
    assert result.success and result.source is not None
    assert "@final\nclass Operations" in result.source
    assert "return x + 2" in result.source


def test_delta_policy_blocks_large_paste_in_short_fork() -> None:
    """A large paste can exceed the mutation budget even within five seconds."""
    from mergekit import DeltaPolicy

    result: MergeResult = SourceMerger(
        original="def f():\n    return 1\n",
        user_edited="def f():\n    return 1\n" + "\n".join(f"value_{i} = {i}" for i in range(100)),
        tool_refactored="def f() -> int:\n    return 1\n",
        language="python",
        delta_policy=DeltaPolicy(max_user_inserted_tokens=40),
        fork_elapsed_seconds=5.0,
    ).merge()
    assert not result.success
    assert any(conflict.kind == "delta_exceeded" for conflict in result.conflicts)


def test_delta_policy_ignores_line_wrapping() -> None:
    """Whitespace-only Python changes do not consume a lexical edit budget."""
    from mergekit import DeltaPolicy, measure

    original: str = "value = calculate(1, 2)\n"
    wrapped: str = "value = calculate(\n    1,\n    2,\n)\n"
    assert measure(original=original, changed=wrapped, language="python").edit_events == 0
    assert DeltaPolicy().short_fork_seconds == 5.0


def test_delta_policy_custom_burst_threshold() -> None:
    """Fast edits may be pasted; enforce configured burst budget without guessing."""
    from mergekit import DeltaPolicy

    result: MergeResult = SourceMerger(
        original="def f():\n    return 1\n",
        user_edited="def f():\n    return 2\n",
        tool_refactored="def f() -> int:\n    return 1\n",
        language="python",
        delta_policy=DeltaPolicy(max_user_tokens_per_second=0.1),
        fork_elapsed_seconds=1.0,
    ).merge()
    assert any(conflict.kind == "delta_exceeded" for conflict in result.conflicts)
