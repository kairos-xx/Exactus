"""Measure end-to-end cold and warm source merge latency without dependencies."""

from __future__ import annotations

from time import perf_counter

from mergekit import SnapshotCache, SourceMerger
from mergekit.model import MergeResult


def main() -> None:
    """Benchmark concurrent single-function edits across increasingly large modules.

    Raises:
        RuntimeError: A benchmark case unexpectedly loses a source mutation.
    """
    print("functions,cold_seconds,warm_seconds,incremental_parses,delta_cache_hits")
    for count in (100, 1000, 5000):
        original: str = "\n".join(
            f"def f{index}(x):\n    return x + {index}\n"
            for index in range(count)
        )
        tool: str = "\n".join(
            f"def f{index}(x: int) -> int:\n    return x + {index}\n"
            for index in range(count)
        )
        cache: SnapshotCache = SnapshotCache()
        periods: list[float] = []
        for mutation in (99991, 99992):
            user: str = original.replace(
                "return x + 2\n", f"return x + {mutation}\n", 1
            )
            start: float = perf_counter()
            result: MergeResult = SourceMerger(
                original=original, user_edited=user, tool_refactored=tool,
                language="python", snapshot_cache=cache,
            ).merge()
            periods.append(perf_counter() - start)
            if not result.success or result.source is None or f"return x + {mutation}" not in result.source:
                msg: str = f"Benchmark failed identity reconciliation at count={count}"
                raise RuntimeError(msg)
        print(
            f"{count},{periods[0]:.5f},{periods[1]:.5f},"
            f"{cache.stats.incremental},{cache.stats.reused_deltas}"
        )


if __name__ == "__main__":
    main()
