"""Reproducible source merge performance benchmarks."""
