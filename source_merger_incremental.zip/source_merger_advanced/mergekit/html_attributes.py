"""Conservative three-way HTML attribute reconciliation by source spans."""

from __future__ import annotations

import html
import re
from dataclasses import dataclass
from typing import final

from mergekit.model import AppliedChange, MergeConflict, Replacement, Unit


@final
@dataclass(frozen=True, slots=True)
class _Attribute:
    """HTML attribute with raw spelling and offset-preserving syntax.

    Attributes:
        name: Case-preserving HTML attribute name.
        value: Parsed semantic attribute value, or None for boolean attributes.
        start: Start of leading whitespace before the attribute.
        end: End of the attribute token.
        raw: Original attribute token with leading whitespace.
    """

    name: str
    value: str | None
    start: int
    end: int
    raw: str


def _read(*, source: str, unit: Unit) -> tuple[str, dict[str, _Attribute]]:
    """Read the element's opening tag without normalizing its serialization.

    Args:
        source: Complete HTML snapshot.
        unit: Syntax record of the element.

    Returns:
        Tag name and its unambiguous attribute mapping.

    Raises:
        ValueError: The tag contains syntactically ambiguous attributes.
    """
    opening: str = source[unit.start:unit.body_start]
    match: re.Match[str] | None = re.match(r"<\s*([\w:-]+)", opening)
    if match is None:
        msg: str = f"Cannot recognize the opening tag at {unit.key}"
        raise ValueError(msg)
    pattern: re.Pattern[str] = re.compile(
        r"\s+([:\w.-]+)(?:\s*=\s*(\"[^\"]*\"|'[^']*'|[^\s>]+))?"
    )
    attributes: dict[str, _Attribute] = {}
    position: int = match.end()
    while position < len(opening):
        if not opening[position:].strip(" />\t\r\n"):
            break
        found: re.Match[str] | None = pattern.match(opening, position)
        if found is None:
            msg = f"Ambiguous attribute syntax for {unit.key}"
            raise ValueError(msg)
        name: str = found.group(1).lower()
        value: str | None = found.group(2)
        if name in attributes:
            msg = f"Duplicate attribute {name} on {unit.key}"
            raise ValueError(msg)
        attributes[name] = _Attribute(
            name=name,
            value=html.unescape(value[1:-1] if value and value[:1] in {"'", '"'} else value) if value else None,
            start=unit.start + found.start(),
            end=unit.start + found.end(),
            raw=found.group(),
        )
        position = found.end()
    return match.group(1), attributes


def reconcile(
    *,
    original_source: str,
    user_source: str,
    tool_source: str,
    original: Unit,
    user: Unit,
    tool: Unit,
) -> tuple[list[Replacement], list[MergeConflict], list[AppliedChange]]:
    """Apply independent user attribute edits to relocated HTML opening tags.

    Args:
        original_source: Common ancestor HTML.
        user_source: User-edited HTML.
        tool_source: Refactored HTML.
        original: Matched common ancestor element.
        user: Matched user element.
        tool: Matched tool element.

    Returns:
        Disjoint opening-tag patches, conflicts, and audit records.
    """
    try:
        original_tag, old_attrs = _read(source=original_source, unit=original)
        user_tag, new_attrs = _read(source=user_source, unit=user)
        _, tool_attrs = _read(source=tool_source, unit=tool)
    except ValueError as error:
        return [], [MergeConflict("unsupported_transformation", original.key, str(error))], []
    if original_tag != user_tag:
        return [], [MergeConflict("structural_change", original.key, "User changed the HTML tag name")], []
    patches: list[Replacement] = []
    conflicts: list[MergeConflict] = []
    applied: list[AppliedChange] = []
    inserted: list[str] = []
    for name in sorted(set(old_attrs) | set(new_attrs)):
        previous: _Attribute | None = old_attrs.get(name)
        own: _Attribute | None = new_attrs.get(name)
        candidate: _Attribute | None = tool_attrs.get(name)
        if previous is not None and own is not None and previous.value == own.value:
            continue
        if previous is None and own is None:
            continue
        if (candidate.value if candidate else None) != (previous.value if previous else None):
            if own is not None and candidate is not None and own.value == candidate.value:
                continue
            conflicts.append(MergeConflict("concurrent_change", original.key, f"Both forks changed HTML attribute {name}"))
            continue
        if own is None and candidate is not None:
            patches.append(Replacement(candidate.start, candidate.end, "", tool.key))
        elif own is not None and candidate is not None:
            patches.append(Replacement(candidate.start, candidate.end, own.raw, tool.key))
        elif own is not None:
            inserted.append(own.raw)
        applied.append(AppliedChange(original.key, "html_attribute", f"Reconciled attribute {name}"))
    if inserted:
        closing: int = tool.body_start - 1
        while closing > tool.start and tool_source[closing - 1].isspace():
            closing -= 1
        if tool_source[closing - 1:closing] == "/":
            closing -= 1
        patches.append(Replacement(closing, closing, "".join(inserted), tool.key))
    return patches, conflicts, applied
