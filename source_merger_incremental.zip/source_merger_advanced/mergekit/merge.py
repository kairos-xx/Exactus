"""Compatibility exports for the earlier source-merger module path."""

from mergekit.engine import SourceMerger, TrackedSourceMerger
from mergekit.model import AppliedChange, MergeConflict, MergeResult, SymbolMatch

__all__ = [
    "AppliedChange", "MergeConflict", "MergeResult", "SourceMerger", "SymbolMatch",
    "TrackedSourceMerger",
]
