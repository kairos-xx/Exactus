"""Conflict-first three-way reconciliation through tracked syntax identities."""

from __future__ import annotations

import difflib
import io
import re
import subprocess
import tempfile
import tokenize
from pathlib import Path
from dataclasses import dataclass, field
from typing import final

from mergekit.cache import SnapshotCache, StatementIndex
from mergekit.delta import DeltaPolicy, violations
from mergekit.expression import project_python_expression
from mergekit.foreign_parser import HtmlParser, NodeParser
from mergekit.html_attributes import reconcile as reconcile_html_attributes
from mergekit.python_imports import collect as collect_imports
from mergekit.python_imports import hide as hide_imports
from mergekit.python_imports import reconcile as reconcile_imports
from mergekit.model import (
    AppliedChange,
    Language,
    MergeConflict,
    MergeResult,
    Replacement,
    Snapshot,
    Statement,
    SymbolMatch,
    Unit,
)
from mergekit.patch import apply, indent_at, insertion, reindent
from mergekit.python_parser import PythonParser
from mergekit.python_literals import literal_replacements
from mergekit.tracking import Tracking, track


def _parse(*, source: str, language: Language) -> Snapshot:
    """Parse source with the language's strict structural frontend.

    Args:
        source: Source-code snapshot.
        language: Declared language.

    Returns:
        Parsed snapshot or parser failure.
    """
    if language == "python":
        return PythonParser().parse(source=source)
    if language == "html":
        return HtmlParser().parse(source=source)
    return NodeParser().parse(source=source, language=language)


def _git_merge(*, original: str, user: str, tool: str) -> tuple[str, bool]:
    """Reconcile unmatched source regions with Git's diff3 engine.

    Args:
        original: Original unmatched content.
        user: User unmatched content.
        tool: Tool unmatched content.

    Returns:
        Merged string and a no-conflict flag.

    Raises:
        RuntimeError: Git was unavailable or the command could not run.
    """
    with tempfile.TemporaryDirectory(prefix="mergekit-") as directory:
        paths: tuple[Path, Path, Path] = tuple(
            Path(directory) / name for name in ("original", "user", "tool")
        )
        for path, content in zip(paths, (original, user, tool), strict=True):
            path.write_text(data=content, encoding="utf-8")
        try:
            process: subprocess.CompletedProcess[bytes] = subprocess.run(
                args=["git", "merge-file", "--diff3", "-p", "user", "original", "tool"],
                cwd=directory, capture_output=True, check=False, timeout=15,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            msg: str = f"Git diff3 unavailable: {error}"
            raise RuntimeError(msg) from error
        if process.returncode not in {0, 1}:
            msg = process.stderr.decode(encoding="utf-8", errors="replace")
            raise RuntimeError(msg or "Git diff3 returned an unexpected status")
        return process.stdout.decode(encoding="utf-8"), process.returncode == 0


def _comments(*, source: str, language: Language) -> tuple[str, ...]:
    """Identify meaningful comments without treating whitespace as content.

    Args:
        source: Text within a tracked source declaration.
        language: Language of the declaration.

    Returns:
        Comment tokens in lexical order.
    """
    if language == "python":
        try:
            return tuple(
                token.string for token in tokenize.generate_tokens(
                    readline=io.StringIO(source).readline
                ) if token.type == tokenize.COMMENT
            )
        except (SyntaxError, tokenize.TokenError, StopIteration):
            return ()
    if language in {"javascript", "typescript", "css"}:
        return tuple(re.findall(r"/\*.*?\*/|(?://[^\n]*)", source, flags=re.DOTALL))
    return tuple(re.findall(r"<!--.*?-->", source, flags=re.DOTALL))


def _rewrite(*, snippet: str, mapping: dict[str, str], language: Language) -> str:
    """Translate verified old identifier references into tool-side names.

    Args:
        snippet: User-added or modified statement.
        mapping: Old or user spelling to refactored spelling.
        language: Language for lexical substitution.

    Returns:
        Syntax-preserving renamed snippet; raises on unsupported ambiguity.
    """
    clean: dict[str, str] = {key: value for key, value in mapping.items() if key != value}
    if not clean:
        return snippet
    if language == "python":
        return PythonParser.rewrite_names(text=snippet, mapping=clean)
    if language == "css":
        result: str = snippet
        for key, value in sorted(clean.items(), key=lambda item: -len(item[0])):
            if not key.startswith("--") or not value.startswith("--"):
                continue
            # Only CSS custom-property definitions and var() references are
            # scope-relevant. Never touch arbitrary strings or URL contents.
            result = re.sub(
                r"(var\(\s*)" + re.escape(key) + r"(?=[\s,)])",
                lambda matched: matched.group(1) + value, result,
            )
            result = re.sub(
                r"(^|[;{]\s*)" + re.escape(key) + r"(?=\s*:)",
                lambda matched: matched.group(1) + value,
                result,
            )
        return result
    if language in {"javascript", "typescript"}:
        return NodeParser().rewrite_identifiers(
            source=snippet, language=language, mapping=clean
        )
    return snippet


def _anchor(*, original: Statement, target: Snapshot, preferred: Unit | None) -> Statement | None:
    """Locate an unchanged statement, even if moved into a new function.

    Args:
        original: Statement in the common ancestor.
        target: Refactored snapshot.
        preferred: Matched declaration where a statement most likely remains.

    Returns:
        Unique structurally matching statement, otherwise None.
    """
    preferred_statements: tuple[Statement, ...] = preferred.statements if preferred else ()
    for choices in (preferred_statements, target.statements):
        candidates: list[Statement] = [item for item in choices if item.shape == original.shape]
        if len(candidates) == 1:
            return candidates[0]
        if original.binding:
            bound: list[Statement] = [item for item in candidates if item.binding == original.binding]
            if len(bound) == 1:
                return bound[0]
        exact: list[Statement] = [item for item in candidates if item.exact == original.exact]
        if len(exact) == 1:
            return exact[0]
    return None


def _name_map(*, original: Unit, user: Unit, tool: Unit) -> dict[str, str]:
    """Derive conservative parameter and local variable substitutions.

    Args:
        original: Ancestor declaration.
        user: User descendant declaration.
        tool: Tool descendant declaration.

    Returns:
        Verified spelling substitutions for user statement projection.
    """
    mapping: dict[str, str] = {}
    for own, new in zip(user.param_names, tool.param_names, strict=False):
        if own != new:
            mapping[own] = new
    for old_statement in original.statements:
        if not old_statement.binding:
            continue
        match: list[Statement] = [
            statement for statement in tool.statements
            if statement.shape == old_statement.shape
        ]
        if len(match) == 1 and match[0].binding and match[0].binding != old_statement.binding:
            mapping[old_statement.binding] = match[0].binding
    return mapping


def _outside_reference_conflicts(
    *, language: Language,
    base: Snapshot, user_snapshot: Snapshot, user_pairs: dict[int, int],
    tool: Snapshot, tool_pairs: dict[int, int],
) -> list[MergeConflict]:
    """Reject user edits that refer to declarations independently renamed by a tool.

    Args:
        language: Parser grammar for source identifiers.
        base: Parsed common ancestor.
        user_snapshot: Parsed user branch.
        user_pairs: Ancestor-to-user declaration matches.
        tool: Parsed tool branch.
        tool_pairs: Ancestor-to-tool declaration matches.

    Returns:
        Reference migration conflicts where scope-aware edits remain necessary.
    """
    renamed: list[tuple[str, str]] = [
        (base.units[index].name, tool.units[position].name)
        for index, position in tool_pairs.items()
        if base.units[index].name != tool.units[position].name
        and base.units[index].kind in {"function", "async_function", "arrow", "assignment"}
    ]
    if not renamed:
        return []
    original_mask: dict[int, int] = {index: index for index in range(len(base.units))}
    user_mask: dict[int, int] = {index: ancestor for ancestor, index in user_pairs.items()}
    try:
        original_skeleton: str = SourceMerger._mask(snapshot=base, matched=original_mask, language=language)
        user_skeleton: str = SourceMerger._mask(snapshot=user_snapshot, matched=user_mask, language=language)
    except ValueError:
        return [MergeConflict("structural_change", "references", "Nested structural identities overlap")]
    before: list[str] = original_skeleton.splitlines(keepends=True)
    after: list[str] = user_skeleton.splitlines(keepends=True)
    changed: str = "".join(
        "".join(after[j1:j2])
        for operation, _i1, _i2, j1, j2 in difflib.SequenceMatcher(
            isjunk=None, a=before, b=after, autojunk=False
        ).get_opcodes() if operation in {"replace", "insert"}
    )
    before: list[str] = original_skeleton.splitlines(keepends=True)
    after: list[str] = user_skeleton.splitlines(keepends=True)
    changed: str = "".join(
        "".join(after[j1:j2])
        for operation, _i1, _i2, j1, j2 in difflib.SequenceMatcher(
            isjunk=None, a=before, b=after, autojunk=False
        ).get_opcodes() if operation in {"replace", "insert"}
    )
    return [
        MergeConflict(
            "unsupported_transformation", "external references",
            f"User modified an unmatched region referring to renamed symbol {old} -> {new}",
        )
        for old, new in renamed
        if re.search(r"(?<![\w$-])" + re.escape(old) + r"(?![\w$-])", changed)
    ]


def _prepare_inline_bodies(
    *, original: Snapshot, user: Snapshot, tool: Snapshot, language: Language,
    cache: SnapshotCache, policy: DeltaPolicy,
) -> Snapshot:
    """Expand inline refactored bodies before statement-level source surgery.

    Args:
        original: Parsed common ancestor.
        user: Parsed user fork.
        tool: Current refactoring source.
        language: Grammar whose inlined blocks may require expansion.

    Returns:
        Refactored snapshot with edit-safe multiline insertion locations.
    """
    if language not in {"javascript", "typescript", "css"}:
        return tool
    users: dict[int, int] = dict(cache.match(
        original=original, changed=user, branch="user",
        minimum_confidence=policy.min_identity_confidence,
        minimum_margin=policy.min_identity_margin,
    ).pairs)
    tools: dict[int, int] = dict(cache.match(
        original=original, changed=tool, branch="tool",
        minimum_confidence=policy.min_identity_confidence,
        minimum_margin=policy.min_identity_margin,
    ).pairs)
    replacements: list[Replacement] = []
    for index, tool_index in tools.items():
        if index not in users:
            continue
        original_unit: Unit = original.units[index]
        user_unit: Unit = user.units[users[index]]
        target: Unit = tool.units[tool_index]
        if [item.exact for item in original_unit.statements] == [item.exact for item in user_unit.statements]:
            continue
        outer: str = indent_at(source=tool.source, position=target.start)
        inner: str = outer + "    "
        body: str = tool.source[target.body_start:target.body_end]
        if target.implicit_return:
            rewritten: str = "{\n" + inner + "return " + body.strip() + ";\n" + outer + "}"
            replacements.append(Replacement(target.body_start, target.body_end, rewritten, target.key))
        elif "\n" not in body and target.statements:
            if "//" in body or "/*" in body:
                continue
            rewritten = "\n" + inner + body.strip() + "\n" + outer
            replacements.append(Replacement(target.body_start, target.body_end, rewritten, target.key))
    if not replacements:
        return tool
    return cache.parse(source=apply(source=tool.source, replacements=tuple(replacements)), language=language)


@final
@dataclass(frozen=True, slots=True, kw_only=True)
class SourceMerger:
    """Reconcile concurrent user changes against identity-tracked refactoring.

    The tool fork is the structural template. No heuristic selection silently
    resolves overlapping semantic changes. Syntax errors and missing parsers
    are errors, not successful merges. Instances are immutable after creation.
    """

    original: str
    user_edited: str
    tool_refactored: str
    language: Language
    delta_policy: DeltaPolicy = field(default_factory=DeltaPolicy)
    fork_elapsed_seconds: float | None = None
    snapshot_cache: SnapshotCache | None = None

    def _result(
        self,
        *,
        source: str | None,
        conflicts: list[MergeConflict],
        matches: list[SymbolMatch],
        applied: list[AppliedChange],
    ) -> MergeResult:
        """Validate source before returning a review-safe merge outcome.

        Args:
            source: Candidate final source.
            conflicts: Unresolved differences.
            matches: Identity tracking evidence.
            applied: Accepted user changes.

        Returns:
            Explicit immutable result; unresolved source is never auto-applied.
        """
        valid: bool | None = None
        if source is not None:
            valid = _parse(source=source, language=self.language).valid
            if not valid:
                conflicts.append(MergeConflict("validation_error", "file", "Merged source fails syntax parsing"))
        return MergeResult(
            source=source if not conflicts else None,
            conflicts=tuple(conflicts), matches=tuple(matches),
            applied_changes=tuple(applied),
            success=not conflicts and source is not None,
            syntax_valid=valid,
        )

    def _assignment(
        self,
        *,
        original: Unit,
        user: Unit,
        tool: Unit,
        mapping: dict[str, str],
    ) -> tuple[list[Replacement], list[MergeConflict], list[AppliedChange]]:
        """Project RHS edits while retaining generated annotations and owners.

        Args:
            original: Base assignment.
            user: User assignment.
            tool: Refactored assignment, possibly moved into a @final class.
            mapping: Verified symbol substitutions.

        Returns:
            Proposed patches, conflicts, and audit changes.
        """
        base: Statement = original.statements[0]
        own: Statement = user.statements[0]
        target: Statement = tool.statements[0]
        if base.binding != own.binding:
            return [], [MergeConflict("unsupported_transformation", original.key, "User-side variable renaming needs full reference migration")], []
        if own.annotation != base.annotation and own.annotation != target.annotation:
            return [], [MergeConflict("concurrent_change", original.key, "User changed an assignment type annotation; annotation migration requires structural reconciliation")], []
        if own.shape == base.shape and own.exact == base.exact:
            return [], [], []
        if own.value_start is None or own.value_end is None or target.value_start is None or target.value_end is None:
            return [], [MergeConflict("unsupported_transformation", original.key, "Unsupported assignment transformation")], []
        if (
            self.language == "python"
            and base.value_start is not None and base.value_end is not None
        ):
            try:
                independent: tuple[Replacement, ...] | None = project_python_expression(
                    original=self.original[base.value_start:base.value_end],
                    user=self.user_edited[own.value_start:own.value_end],
                    tool=self.tool_refactored[target.value_start:target.value_end],
                    tool_start=target.value_start, mapping=mapping, scope=tool.key,
                )
            except ValueError as error:
                return [], [MergeConflict(
                    "unsupported_transformation", original.key, str(error)
                )], []
            if independent is None:
                return [], [MergeConflict(
                    "concurrent_change", original.key,
                    "User and tool modified overlapping assignment expression paths",
                )], []
            return list(independent), [], [AppliedChange(
                original.key, "assignment_expression",
                "Preserved independently refactored RHS and type annotations",
            )] if independent else []
        if target.shape != base.shape and target.shape != own.shape:
            return [], [MergeConflict(
                "concurrent_change", original.key, "Both forks changed the assignment value"
            )], []
        if target.shape == own.shape and target.exact == own.exact:
            return [], [], []
        user_source: str = self.user_edited[own.value_start:own.value_end]
        value: str = user_source
        try:
            value = _rewrite(snippet=user_source, mapping=mapping, language=self.language)
        except ValueError as error:
            return [], [MergeConflict("unsupported_transformation", original.key, str(error))], []
        return [Replacement(target.value_start, target.value_end, value, tool.key)], [], [
            AppliedChange(original.key, "assignment_value", "Preserved generated type annotation and declaration relocation")
        ]

    def _body(
        self,
        *,
        original: Unit,
        user: Unit,
        tool: Unit,
        tool_snapshot: Snapshot,
        mapping: dict[str, str],
    ) -> tuple[list[Replacement], list[MergeConflict], list[AppliedChange]]:
        """Reconcile statement-level edits across reorganization and renaming.

        Args:
            original: Common-ancestor callable.
            user: Current user callable.
            tool: Callable in the refactored fork.
            tool_snapshot: All source statements, including extracted helpers.
            mapping: Verified user-to-tool symbol spellings.

        Returns:
            Proposed nonoverlapping edits, conflicts, and provenance records.
        """
        old: tuple[Statement, ...] = original.statements
        own: tuple[Statement, ...] = user.statements
        patches: list[Replacement] = []
        conflicts: list[MergeConflict] = []
        applied: list[AppliedChange] = []
        index: StatementIndex = StatementIndex(snapshot=tool_snapshot)
        matcher: difflib.SequenceMatcher[str] = difflib.SequenceMatcher(
            isjunk=None, a=[item.exact for item in old],
            b=[item.exact for item in own], autojunk=False,
        )

        def edit(*, original_item: Statement, user_item: Statement) -> None:
            """Transfer a changed statement to its unique tool-side descendant."""
            if original_item.annotation != user_item.annotation:
                conflicts.append(MergeConflict("concurrent_change", original.key, "User changed a local declaration annotation"))
                return
            if original_item.exact == user_item.exact and original_item.shape == user_item.shape:
                return
            target: Statement | None = index.locate(original=original_item, preferred=tool)
            if target is None and self.language == "python":
                target = index.locate_mutated(original=original_item, preferred=tool)
            if target is None:
                conflicts.append(MergeConflict(
                    "missing_anchor", original.key, "A changed statement moved or changed without unique correspondence"
                ))
                return
            if (
                self.language == "python"
                and original_item.value_start is not None and original_item.value_end is not None
                and user_item.value_start is not None and user_item.value_end is not None
                and target.value_start is not None and target.value_end is not None
            ):
                try:
                    independent: tuple[Replacement, ...] | None = project_python_expression(
                        original=self.original[original_item.value_start:original_item.value_end],
                        user=self.user_edited[user_item.value_start:user_item.value_end],
                        tool=tool_snapshot.source[target.value_start:target.value_end],
                        tool_start=target.value_start, mapping=mapping, scope=tool.key,
                    )
                except ValueError as error:
                    conflicts.append(MergeConflict(
                        "unsupported_transformation", original.key, str(error)
                    ))
                    return
                if independent is None:
                    conflicts.append(MergeConflict(
                        "concurrent_change", original.key,
                        "User and tool modified overlapping expression-tree paths",
                    ))
                    return
                if independent:
                    patches.extend(independent)
                    applied.append(AppliedChange(
                        original.key, "expression_edit", "Projected changed expression subtrees"
                    ))
                return
            user_fragment: str = self.user_edited[user_item.start:user_item.end]
            try:
                fragment: str = _rewrite(snippet=user_fragment, mapping=mapping, language=self.language)
            except ValueError as error:
                conflicts.append(MergeConflict("unsupported_transformation", original.key, str(error)))
                return
            if original_item.shape != target.shape:
                if user_item.shape == target.shape:
                    return
                conflicts.append(MergeConflict(
                    "concurrent_change", original.key, "Both forks changed the same statement's semantics"
                ))
                return
            if self.language == "python":
                literals: tuple[Replacement, ...] | None = literal_replacements(
                    original_source=self.original, user_source=self.user_edited,
                    tool_source=tool_snapshot.source,
                    original=original_item, user=user_item, tool=target,
                )
                if literals is not None:
                    patches.extend(literals)
                    applied.append(AppliedChange(
                        original.key, "literal_edit", "Preserved tool wrapping while replacing changed literal leaves"
                    ))
                    return
            if (
                self.language == "python"
                and original_item.kind in {"Assign", "AnnAssign"}
                and user_item.kind in {"Assign", "AnnAssign"}
                and target.kind in {"Assign", "AnnAssign"}
                and original_item.binding == user_item.binding
                and user_item.value_start is not None and user_item.value_end is not None
                and target.value_start is not None and target.value_end is not None
            ):
                value: str = self.user_edited[user_item.value_start:user_item.value_end]
                patches.append(Replacement(
                    target.value_start, target.value_end,
                    _rewrite(snippet=value, mapping=mapping, language=self.language),
                    tool.key,
                ))
            elif self.language == "css" and user_item.value_start is not None and target.value_start is not None:
                raw: str = self.user_edited[user_item.value_start:user_item.value_end]
                fragment = _rewrite(snippet=raw, mapping=mapping, language=self.language)
                patches.append(Replacement(target.value_start, target.value_end or target.value_start, fragment, tool.key))
            else:
                patches.append(Replacement(
                    target.start, target.end,
                    reindent(
                        text=fragment,
                        target=indent_at(source=tool_snapshot.source, position=target.start),
                        origin=indent_at(source=self.user_edited, position=user_item.start),
                    ), tool.key,
                ))
            applied.append(AppliedChange(original.key, "statement_edit", "Projected into unique refactored statement"))

        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == "equal":
                for base_item, user_item in zip(old[i1:i2], own[j1:j2], strict=True):
                    edit(original_item=base_item, user_item=user_item)
            elif tag == "replace" and i2 - i1 == j2 - j1:
                for base_item, user_item in zip(old[i1:i2], own[j1:j2], strict=True):
                    edit(original_item=base_item, user_item=user_item)
            elif tag == "replace" and i2 - i1 == 1:
                target = index.locate(original=old[i1], preferred=tool)
                if target is None:
                    conflicts.append(MergeConflict("missing_anchor", original.key, "Cannot locate replaced statement block"))
                    continue
                first: Statement = own[j1]
                last: Statement = own[j2 - 1]
                raw = self.user_edited[first.start:last.end]
                try:
                    rewritten: str = _rewrite(snippet=raw, mapping=mapping, language=self.language)
                except ValueError as error:
                    conflicts.append(MergeConflict("unsupported_transformation", original.key, str(error)))
                    continue
                patches.append(Replacement(
                    target.start, target.end,
                    reindent(text=rewritten,
                             target=indent_at(source=tool_snapshot.source, position=target.start),
                             origin=indent_at(source=self.user_edited, position=first.start)),
                    tool.key,
                ))
                applied.append(AppliedChange(original.key, "statement_block", "Transferred complete replacement block"))
            elif tag == "delete":
                for original_item in old[i1:i2]:
                    target = index.locate(original=original_item, preferred=tool)
                    if target is None:
                        conflicts.append(MergeConflict("missing_anchor", original.key, "Deletion targets an untracked or modified statement"))
                        continue
                    start: int = tool_snapshot.source.rfind("\n", 0, target.start) + 1
                    end: int = tool_snapshot.source.find("\n", target.end)
                    patches.append(Replacement(start, len(tool_snapshot.source) if end < 0 else end + 1, "", tool.key))
                    applied.append(AppliedChange(original.key, "statement_delete", "Deleted statement at its new location"))
            elif tag == "insert":
                following: Statement | None = old[i1] if i1 < len(old) else None
                preceding: Statement | None = old[i1 - 1] if i1 else None
                anchor: Statement | None = (
                    index.locate(original=following, preferred=tool)
                    if following is not None else None
                )
                before: bool = anchor is not None
                if anchor is None and preceding is not None:
                    anchor = index.locate(original=preceding, preferred=tool)
                if anchor is None:
                    conflicts.append(MergeConflict("missing_anchor", original.key, "New statement has no uniquely tracked insertion context"))
                    continue
                first = own[j1]
                last = own[j2 - 1]
                try:
                    fragment = _rewrite(
                        snippet=self.user_edited[first.start:last.end],
                        mapping=mapping, language=self.language,
                    )
                except ValueError as error:
                    conflicts.append(MergeConflict("unsupported_transformation", original.key, str(error)))
                    continue
                patches.append(insertion(
                    source=tool_snapshot.source, anchor=anchor,
                    before=before, snippet=fragment,
                    origin=indent_at(source=self.user_edited, position=first.start),
                ))
                applied.append(AppliedChange(original.key, "statement_insert", "Inserted adjacent to tracked refactoring survivor"))
            else:
                conflicts.append(MergeConflict(
                    "unsupported_transformation", original.key,
                    "Complex simultaneous block surgery requires manual reconciliation",
                ))
        return patches, conflicts, applied

    @staticmethod
    def _mask(*, snapshot: Snapshot, matched: dict[int, int], language: Language) -> str:
        """Replace matched units with stable ancestor placeholders.

        Args:
            snapshot: Parsed source version.
            matched: Mapping from current unit index to ancestor index.
            language: Source syntax for placeholder comments.

        Returns:
            Source skeleton preserving all unmatched edits and tool movements.
        """
        replacements: list[Replacement] = []
        for current, base_index in matched.items():
            unit: Unit = snapshot.units[current]
            sentinel: str = f"MERGEKIT_UNIT_{base_index:08d}"
            marker: str = (
                f"# {sentinel}" if language == "python"
                else f"<!-- {sentinel} -->" if language == "html"
                else f"/* {sentinel} */"
            )
            replacements.append(Replacement(unit.start, unit.end, marker, unit.key))
        return apply(source=snapshot.source, replacements=tuple(replacements))

    @staticmethod
    def _expand(*, source: str, units: dict[int, str]) -> str:
        """Restore declarations into the final structure after skeleton merge.

        Args:
            source: Merged source skeleton.
            units: Complete tool-rendered unit source by ancestor index.

        Returns:
            Source with identity tokens expanded into refactored declarations.
        """
        pattern: str = r"(?:#|/\*|<!--)[ \t]*MERGEKIT_UNIT_(\d{8})[ \t]*(?:\*/|-->)?"
        return re.sub(
            pattern,
            lambda matched: units.get(int(matched.group(1)), matched.group(0)),
            source,
        )


    def merge(self) -> MergeResult:
        """Perform conservative identity-aware three-way source reconciliation.

        Returns:
            Merged source when unambiguous, else a structured conflict result.
        """
        conflicts: list[MergeConflict] = []
        applied: list[AppliedChange] = []
        matches: list[SymbolMatch] = []
        cache: SnapshotCache = self.snapshot_cache or SnapshotCache()
        if self.delta_policy is not None:
            user_delta = cache.delta(
                original=self.original, changed=self.user_edited, language=self.language
            )
            tool_delta = cache.delta(
                original=self.original, changed=self.tool_refactored, language=self.language
            )
            conflicts.extend(
                MergeConflict("delta_exceeded", "fork mutation budget", detail)
                for detail in violations(
                    user=user_delta, tool=tool_delta, policy=self.delta_policy,
                    elapsed_seconds=self.fork_elapsed_seconds,
                )
            )
            if conflicts:
                return self._result(source=None, conflicts=conflicts, matches=matches, applied=applied)
        if self.original == self.user_edited:
            return self._result(source=self.tool_refactored, conflicts=conflicts, matches=matches, applied=applied)
        if self.original == self.tool_refactored or self.user_edited == self.tool_refactored:
            return self._result(source=self.user_edited, conflicts=conflicts, matches=matches, applied=applied)
        base: Snapshot
        user: Snapshot
        tool: Snapshot
        base, user, tool = cache.parse_forks(
            original=self.original, user=self.user_edited, tool=self.tool_refactored,
            language=self.language,
        )
        for name, snapshot in (("original", base), ("user", user), ("tool", tool)):
            if not snapshot.valid:
                conflicts.append(MergeConflict("parse_error", name, snapshot.error))
        if conflicts:
            return self._result(source=None, conflicts=conflicts, matches=matches, applied=applied)
        try:
            tool = _prepare_inline_bodies(
                original=base, user=user, tool=tool, language=self.language,
                cache=cache, policy=self.delta_policy,
            )
        except ValueError as error:
            conflicts.append(MergeConflict("unsupported_transformation", "inline bodies", str(error)))
            return self._result(source=None, conflicts=conflicts, matches=matches, applied=applied)
        if not tool.valid:
            conflicts.append(MergeConflict("parse_error", "normalized refactor", tool.error))
            return self._result(source=None, conflicts=conflicts, matches=matches, applied=applied)
        user_tracking: Tracking = cache.match(
            original=base, changed=user, branch="user",
            minimum_confidence=self.delta_policy.min_identity_confidence,
            minimum_margin=self.delta_policy.min_identity_margin,
        )
        tool_tracking: Tracking = cache.match(
            original=base, changed=tool, branch="tool",
            minimum_confidence=self.delta_policy.min_identity_confidence,
            minimum_margin=self.delta_policy.min_identity_margin,
        )
        matches.extend((*user_tracking.matches, *tool_tracking.matches))
        for index in set(user_tracking.ambiguous) | set(tool_tracking.ambiguous):
            conflicts.append(MergeConflict("ambiguous_identity", base.units[index].key, "Multiple plausible declarations have similar identities"))
        user_pairs: dict[int, int] = dict(user_tracking.pairs)
        tool_pairs: dict[int, int] = dict(tool_tracking.pairs)
        conflicts.extend(_outside_reference_conflicts(
            language=self.language,
            base=base, user_snapshot=user, user_pairs=user_pairs, tool=tool,
            tool_pairs=tool_pairs,
        ))
        patches: list[Replacement] = []
        name_counts: dict[str, int] = {}
        for unit in base.units:
            name_counts[unit.name] = name_counts.get(unit.name, 0) + 1
        global_renames: dict[str, str] = {
            base.units[ancestor].name: tool.units[index].name
            for ancestor, index in tool_pairs.items()
            if base.units[ancestor].name != tool.units[index].name
            and name_counts[base.units[ancestor].name] == 1
        }
        for index, original_unit in enumerate(base.units):
            if index not in user_pairs or index not in tool_pairs:
                if index in user_pairs and index not in tool_pairs:
                    own = user.units[user_pairs[index]]
                    if self.user_edited[own.start:own.end] != self.original[original_unit.start:original_unit.end]:
                        conflicts.append(MergeConflict("structural_change", original_unit.key, "Refactor removed an independently edited declaration"))
                continue
            own = user.units[user_pairs[index]]
            target = tool.units[tool_pairs[index]]
            if (
                self.original[original_unit.start:original_unit.end]
                == self.user_edited[own.start:own.end]
            ):
                continue
            if own.name != original_unit.name and target.name != own.name and original_unit.kind != "element":
                conflicts.append(MergeConflict(
                    "unsupported_transformation", original_unit.key,
                    "User renamed a declaration differently from the tool; references require scope resolution",
                ))
                continue
            if own.parent != original_unit.parent and target.parent != original_unit.parent and target.parent != own.parent:
                conflicts.append(MergeConflict("concurrent_change", original_unit.key, "Both forks relocated the declaration to different owners"))
                continue
            if (
                original_unit.kind in {"function", "async_function", "arrow"}
                and (original_unit.header_semantic != own.header_semantic
                     or original_unit.signature != own.signature)
            ):
                conflicts.append(MergeConflict("unsupported_transformation", original_unit.key, "User modified a callable signature, annotation or decorator"))
                continue
            if original_unit.kind == "assignment":
                local_patches, local_conflicts, local_applied = self._assignment(
                    original=original_unit, user=own, tool=target, mapping={},
                )
            elif original_unit.kind in {"function", "async_function", "arrow", "rule"}:
                mapping: dict[str, str] = _name_map(
                    original=original_unit, user=own, tool=target,
                )
                mapping.update(global_renames)
                local_patches, local_conflicts, local_applied = self._body(
                    original=original_unit, user=own, tool=target,
                    tool_snapshot=tool, mapping=mapping,
                )
            elif original_unit.kind == "element":
                original_content: str = self.original[original_unit.body_start:original_unit.body_end]
                user_content: str = self.user_edited[own.body_start:own.body_end]
                tool_content: str = tool.source[target.body_start:target.body_end]
                try:
                    merged_content: str
                    okay: bool
                    merged_content, okay = _git_merge(
                        original=original_content, user=user_content, tool=tool_content,
                    )
                except RuntimeError as error:
                    conflicts.append(MergeConflict("textual_conflict", original_unit.key, str(error)))
                    continue
                if not okay:
                    conflicts.append(MergeConflict("textual_conflict", original_unit.key, "Overlapping changes inside moved HTML element"))
                    continue
                if user_content != original_content:
                    patches.append(Replacement(target.body_start, target.body_end, merged_content, target.key))
                    applied.append(AppliedChange(original_unit.key, "html_subtree", "Transferred child edits into refactored HTML element"))
                attributes, attr_conflicts, attr_applied = reconcile_html_attributes(
                    original_source=self.original, user_source=self.user_edited,
                    tool_source=tool.source, original=original_unit, user=own, tool=target,
                )
                patches.extend(attributes)
                conflicts.extend(attr_conflicts)
                applied.extend(attr_applied)
                local_patches, local_conflicts, local_applied = [], [], []
            else:
                local_patches, local_conflicts, local_applied = [], [], []
            patches.extend(local_patches)
            conflicts.extend(local_conflicts)
            applied.extend(local_applied)
            if original_unit.kind != "element" and _comments(
                source=self.original[original_unit.start:original_unit.end], language=self.language,
            ) != _comments(source=self.user_edited[own.start:own.end], language=self.language):
                conflicts.append(MergeConflict("unsupported_transformation", original_unit.key, "Concurrent user comment changes require CST-aware attachment tracking"))
        if conflicts:
            return self._result(source=None, conflicts=conflicts, matches=matches, applied=applied)
        try:
            updated_tool: str = apply(source=tool.source, replacements=tuple(patches))
        except ValueError as error:
            conflicts.append(MergeConflict("concurrent_change", "patches", str(error)))
            return self._result(source=None, conflicts=conflicts, matches=matches, applied=applied)
        patched: Snapshot = cache.parse(source=updated_tool, language=self.language)
        if not patched.valid:
            conflicts.append(MergeConflict("validation_error", "patched refactor", patched.error))
            return self._result(source=None, conflicts=conflicts, matches=matches, applied=applied)
        patched_tracking: Tracking = cache.match(
            original=base, changed=patched, branch="tool",
            minimum_confidence=self.delta_policy.min_identity_confidence,
            minimum_margin=self.delta_policy.min_identity_margin,
        )
        patched_pairs: dict[int, int] = dict(patched_tracking.pairs)
        original_mask: dict[int, int] = {index: index for index in range(len(base.units))}
        user_mask: dict[int, int] = {index: ancestor for ancestor, index in user_pairs.items()}
        tool_mask: dict[int, int] = {index: ancestor for ancestor, index in patched_pairs.items()}
        try:
            base_skeleton: str = self._mask(snapshot=base, matched=original_mask, language=self.language)
            user_skeleton: str = self._mask(snapshot=user, matched=user_mask, language=self.language)
            tool_skeleton: str = self._mask(snapshot=patched, matched=tool_mask, language=self.language)
            import_text: str | None = None
            if self.language == "python":
                base_imports = collect_imports(source=base_skeleton)
                user_imports = collect_imports(source=user_skeleton)
                tool_imports = collect_imports(source=tool_skeleton)
                if base_imports and user_imports and tool_imports:
                    import_text, import_conflicts = reconcile_imports(
                        original=base_imports, user=user_imports, tool=tool_imports,
                    )
                    conflicts.extend(import_conflicts)
                    if not import_conflicts and import_text is not None:
                        base_skeleton = hide_imports(source=base_skeleton, region=base_imports)
                        user_skeleton = hide_imports(source=user_skeleton, region=user_imports)
                        tool_skeleton = hide_imports(source=tool_skeleton, region=tool_imports)
            if conflicts:
                return self._result(source=None, conflicts=conflicts, matches=matches, applied=applied)
            skeleton: str
            clean: bool
            skeleton, clean = _git_merge(original=base_skeleton, user=user_skeleton, tool=tool_skeleton)
        except (RuntimeError, ValueError) as error:
            conflicts.append(MergeConflict("textual_conflict", "skeleton", str(error)))
            return self._result(source=None, conflicts=conflicts, matches=matches, applied=applied)
        if not clean:
            conflicts.append(MergeConflict("textual_conflict", "skeleton", "Concurrent unmatched edits conflict after tracked declarations are separated"))
            return self._result(source=None, conflicts=conflicts, matches=matches, applied=applied)
        content: dict[int, str] = {
            ancestor: updated_tool[patched.units[index].start:patched.units[index].end]
            for ancestor, index in patched_pairs.items()
        }
        for ancestor, index in user_pairs.items():
            if ancestor not in content:
                content[ancestor] = self.user_edited[user.units[index].start:user.units[index].end]
        result: str = self._expand(source=skeleton, units=content)
        if import_text is not None:
            result = result.replace("# MERGEKIT_IMPORT_BLOCK\n", import_text)
        if "MERGEKIT_IMPORT_BLOCK" in result:
            conflicts.append(MergeConflict("structural_change", "imports", "Import placeholder was not resolved"))
        if "MERGEKIT_UNIT_" in result:
            conflicts.append(MergeConflict("structural_change", "skeleton", "Source placeholders could not be resolved uniquely"))
        return self._result(source=result, conflicts=conflicts, matches=matches, applied=applied)


TrackedSourceMerger = SourceMerger
