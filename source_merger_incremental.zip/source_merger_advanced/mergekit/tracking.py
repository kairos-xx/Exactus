"""Indexed hierarchical identity matching for independently refactored source trees."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import final

from mergekit.model import Snapshot, SymbolMatch, Unit


@final
@dataclass(frozen=True, slots=True)
class Tracking:
    """One-to-one correspondences, ambiguous ancestors, and audit matches.

    Attributes:
        pairs: Ancestor and fork declaration indices.
        ambiguous: Ancestors whose identity cannot be established safely.
        matches: Auditable correspondences and confidence estimates.
    """

    pairs: tuple[tuple[int, int], ...]
    ambiguous: tuple[int, ...]
    matches: tuple[SymbolMatch, ...]


@final
class Constants:
    """Bound candidate expansion and matching work for large files.

    Attributes:
        minimum_score: Lowest accepted identity confidence.
        minimum_margin: Required advantage over competing identities.
        max_candidates: Maximum candidates scored per unmatched declaration.
        max_scope_candidates: Scope-local fallback candidates considered.
        max_fuzzy_chars: Character budget for approximate body matching.
    """

    minimum_score: float = 0.72
    minimum_margin: float = 0.09
    max_candidates: int = 32
    max_scope_candidates: int = 24
    max_fuzzy_chars: int = 8192


def _compatible(*, base: Unit, candidate: Unit) -> bool:
    """Accept equivalent declaration categories, including arrow conversions.

    Args:
        base: Ancestor declaration.
        candidate: Fork declaration.

    Returns:
        Whether their declaration categories can correspond.
    """
    return base.kind == candidate.kind or {base.kind, candidate.kind} == {
        "function", "arrow"
    }


def _score(*, base: Unit, candidate: Unit) -> float:
    """Score a candidate only after indexed retrieval.

    Args:
        base: Ancestor declaration.
        candidate: Fork declaration.

    Returns:
        Identity confidence surrogate between zero and one.
    """
    if not _compatible(base=base, candidate=candidate):
        return 0.0
    if base.key == candidate.key:
        return 1.0
    if base.fingerprint and base.fingerprint == candidate.fingerprint:
        return (0.975 if base.signature == candidate.signature else 0.945) + (
            0.019 if base.name == candidate.name else 0.0
        )
    if len(base.fingerprint) + len(candidate.fingerprint) > Constants.max_fuzzy_chars:
        return 0.0
    base_shapes: tuple[str, ...] = tuple(item.shape for item in base.statements)
    candidate_shapes: tuple[str, ...] = tuple(
        item.shape for item in candidate.statements
    )
    similarity: float = max(
        SequenceMatcher(
            isjunk=None, a=base_shapes, b=candidate_shapes, autojunk=False
        ).ratio(),
        SequenceMatcher(
            isjunk=None, a="|".join(base_shapes),
            b="|".join(candidate_shapes), autojunk=False,
        ).ratio(),
    )
    spelling: float = SequenceMatcher(
        isjunk=None, a=base.name, b=candidate.name, autojunk=False
    ).ratio()
    return min(1.0,
        0.61 * similarity
        + 0.13 * spelling
        + (0.13 if base.parent == candidate.parent else 0.0)
        + (0.13 if base.signature == candidate.signature else 0.0)
        + (0.05 if base.name == candidate.name else 0.0)
    )


def track(
    *, original: Snapshot, changed: Snapshot, branch: str,
    minimum_confidence: float = Constants.minimum_score,
    minimum_margin: float = Constants.minimum_margin,
) -> Tracking:
    """Match declarations using hierarchical indexes and bounded fuzzy search.

    Exact qualified identities are resolved first, then unique body fingerprints,
    then indexed rename/move candidates. Parent correspondences guide the final
    fuzzy pass. Ambiguous or oversized candidate groups are never guessed.

    Args:
        original: Common-ancestor snapshot.
        changed: User or tool fork.
        branch: Fork label for audit records.
        minimum_confidence: Lowest accepted nonexact identity confidence.
        minimum_margin: Required gap from competing candidates.

    Returns:
        Unique, conservative declaration correspondences.
    """
    by_key: dict[str, list[int]] = defaultdict(list)
    by_fingerprint: dict[tuple[str, str], list[int]] = defaultdict(list)
    by_name: dict[tuple[str, str], list[int]] = defaultdict(list)
    by_parent: dict[tuple[str, str], list[int]] = defaultdict(list)
    by_signature: dict[tuple[str, str], list[int]] = defaultdict(list)
    for index, unit in enumerate(changed.units):
        by_key[unit.key].append(index)
        by_fingerprint[(unit.kind, unit.fingerprint)].append(index)
        by_name[(unit.kind, unit.name)].append(index)
        by_parent[(unit.kind, unit.parent)].append(index)
        by_signature[(unit.kind, unit.signature)].append(index)
        if unit.kind == "arrow":
            by_fingerprint[("function", unit.fingerprint)].append(index)
            by_name[("function", unit.name)].append(index)
            by_parent[("function", unit.parent)].append(index)
            by_signature[("function", unit.signature)].append(index)
    assigned_base: set[int] = set()
    assigned_fork: set[int] = set()
    ambiguous: set[int] = set()
    pairs: list[tuple[int, int]] = []
    confidence: dict[tuple[int, int], float] = {}

    def assign(*, base_index: int, fork_index: int, score: float) -> None:
        """Commit a uniquely identified declaration correspondence.

        Args:
            base_index: Ancestor unit index.
            fork_index: Fork unit index.
            score: Identity confidence.
        """
        assigned_base.add(base_index)
        assigned_fork.add(fork_index)
        pairs.append((base_index, fork_index))
        confidence[(base_index, fork_index)] = score

    for index, base in enumerate(original.units):
        matches: list[int] = [
            target for target in by_key[base.key]
            if target not in assigned_fork
            and _compatible(base=base, candidate=changed.units[target])
        ]
        if len(matches) == 1:
            assign(base_index=index, fork_index=matches[0], score=1.0)
        elif len(matches) > 1:
            ambiguous.add(index)

    for index, base in enumerate(original.units):
        if index in assigned_base or index in ambiguous or not base.fingerprint:
            continue
        matches = [
            target for target in by_fingerprint[(base.kind, base.fingerprint)]
            if target not in assigned_fork
            and _compatible(base=base, candidate=changed.units[target])
        ]
        if len(matches) == 1:
            target = matches[0]
            score: float = _score(base=base, candidate=changed.units[target])
            if score >= minimum_confidence:
                assign(base_index=index, fork_index=target, score=score)
        elif len(matches) > 1:
            ambiguous.add(index)

    parent_aliases: dict[str, str] = {
        original.units[base_index].key: changed.units[fork_index].key
        for base_index, fork_index in pairs
    }
    # Restrict fuzzy scoring to indexed names, signatures, and lexical scopes.
    # A moved declaration remains discoverable through its name or signature.
    pending: dict[int, list[tuple[float, int]]] = {}
    reverse: dict[int, list[tuple[float, int]]] = defaultdict(list)
    for index, base in enumerate(original.units):
        if index in assigned_base or index in ambiguous:
            continue
        candidates: set[int] = set(by_name[(base.kind, base.name)])
        signed: list[int] = by_signature[(base.kind, base.signature)]
        if len(signed) <= Constants.max_scope_candidates:
            candidates.update(signed)
        scoped_parent: str = parent_aliases.get(base.parent, base.parent)
        local: list[int] = by_parent[(base.kind, scoped_parent)]
        if len(local) <= Constants.max_scope_candidates:
            candidates.update(local)
        if len(candidates) > Constants.max_candidates:
            # Never truncate a candidate set: doing so could hide a better match.
            ambiguous.add(index)
            continue
        ranked: list[tuple[float, int]] = sorted(
            (
                (_score(base=base, candidate=changed.units[target]), target)
                for target in candidates
                if target not in assigned_fork
                and _compatible(base=base, candidate=changed.units[target])
            ),
            key=lambda entry: (-entry[0], entry[1]),
        )
        if not ranked or ranked[0][0] < minimum_confidence:
            continue
        pending[index] = ranked
        for score, target in ranked:
            reverse[target].append((score, index))
    for index, ranked in sorted(
        pending.items(), key=lambda item: (-item[1][0][0], item[0])
    ):
        if index in ambiguous:
            continue
        score, target = ranked[0]
        second: float = ranked[1][0] if len(ranked) > 1 else 0.0
        rivals: float = max(
            (value for value, rival in reverse[target] if rival != index),
            default=0.0,
        )
        if max(second, rivals) >= score - minimum_margin:
            ambiguous.add(index)
        elif target not in assigned_fork:
            assign(base_index=index, fork_index=target, score=score)
        else:
            ambiguous.add(index)
    return Tracking(
        pairs=tuple(sorted(pairs)),
        ambiguous=tuple(sorted(ambiguous)),
        matches=tuple(
            SymbolMatch(
                original=original.units[index].key,
                changed=changed.units[target].key,
                branch="user" if branch == "user" else "tool",
                confidence=confidence[(index, target)],
                kind=original.units[index].kind,
            )
            for index, target in sorted(pairs)
        ),
    )
