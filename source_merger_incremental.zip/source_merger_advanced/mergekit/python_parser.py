"""Parse Python into source-precise, rename-insensitive structural records."""

from __future__ import annotations

import ast
import io
import tokenize
from collections.abc import Iterable
from typing import final

from mergekit.model import Snapshot, Statement, Unit


@final
class PythonParser:
    """Extract scopes and statements without modifying user source text."""

    @staticmethod
    def offset(*, source: str, line: int, col: int) -> int:
        """Convert AST UTF-8 byte columns to Python string offsets.

        Args:
            source: Complete source text.
            line: One-indexed source line.
            col: Byte-based AST column offset.

        Returns:
            Character offset in the source string.
        """
        lines: list[str] = source.splitlines(keepends=True)
        return sum(map(len, lines[:line - 1])) + len(
            lines[line - 1].encode(encoding="utf-8")[:col].decode(encoding="utf-8")
        )

    @staticmethod
    def _fast_offset(*, source: str, offsets: tuple[int, ...], line: int, col: int) -> int:
        """Locate an AST UTF-8 column in amortized O(line length).

        Args:
            source: Original Unicode source text.
            offsets: Precomputed character offsets of each line.
            line: One-based AST line position.
            col: Zero-based AST UTF-8 byte column.

        Returns:
            Character offset in the full source string.
        """
        beginning: int = offsets[line - 1]
        return beginning + len(
            source[beginning:offsets[line]].encode(encoding="utf-8")[:col].decode(encoding="utf-8")
        )

    @staticmethod
    def _shape(*, node: ast.AST, ignore_names: bool) -> str:
        """Build a deterministic syntax fingerprint with annotations erased.

        Args:
            node: Python AST node.
            ignore_names: Whether to abstract all bound identifier spellings.

        Returns:
            Serialized recursively normalized syntax tree.
        """
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets: Iterable[ast.expr] = node.targets if isinstance(node, ast.Assign) else (node.target,)
            return "assign(" + ",".join(
                PythonParser._shape(node=target, ignore_names=ignore_names)
                for target in targets
            ) + "," + (
                PythonParser._shape(node=node.value, ignore_names=ignore_names)
                if node.value is not None else "none"
            ) + ")"
        if isinstance(node, ast.Name):
            return "id" if ignore_names else f"id:{node.id}"
        if isinstance(node, ast.arg):
            return "arg" if ignore_names else f"arg:{node.arg}"
        if isinstance(node, ast.Attribute):
            return "attr(" + PythonParser._shape(node=node.value, ignore_names=ignore_names) + "," + (
                "attr" if ignore_names else node.attr
            ) + ")"
        if isinstance(node, ast.Constant):
            return f"{type(node.value).__name__}:{node.value!r}"
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            return "function(" + ",".join(
                PythonParser._shape(node=child, ignore_names=ignore_names)
                for child in node.body
            ) + ")"
        if isinstance(node, ast.ClassDef):
            return "class(" + ",".join(
                PythonParser._shape(node=child, ignore_names=ignore_names)
                for child in node.body
            ) + ")"
        pieces: list[str] = [type(node).__name__]
        for field, value in ast.iter_fields(node):
            if field in {"annotation", "type_comment", "type_params", "decorator_list", "returns"}:
                continue
            if isinstance(value, ast.AST):
                pieces.append(PythonParser._shape(node=value, ignore_names=ignore_names))
            elif isinstance(value, list):
                pieces.extend(
                    PythonParser._shape(node=item, ignore_names=ignore_names)
                    for item in value if isinstance(item, ast.AST)
                )
            elif field != "ctx":
                pieces.append(str(value))
        return "(".join([pieces[0], ",".join(pieces[1:]) + ")"])

    @staticmethod
    def _statement(*, source: str, node: ast.stmt, offsets: tuple[int, ...]) -> Statement:
        """Create a statement record with optional assignment RHS offsets.

        Args:
            source: Complete Python source.
            node: Parsed statement.

        Returns:
            Offset-backed statement identity.
        """
        value: ast.expr | None = node.value if isinstance(node, (ast.Assign, ast.AnnAssign, ast.Return, ast.Expr)) else None
        target: ast.expr | None = (
            node.targets[0] if isinstance(node, ast.Assign) and len(node.targets) == 1
            else node.target if isinstance(node, ast.AnnAssign) else None
        )
        return Statement(
            kind=type(node).__name__,
            start=PythonParser._fast_offset(source=source, offsets=offsets, line=node.lineno, col=node.col_offset),
            end=PythonParser._fast_offset(source=source, offsets=offsets, line=node.end_lineno or node.lineno, col=node.end_col_offset or 0),
            shape=PythonParser._shape(node=node, ignore_names=True),
            exact=PythonParser._shape(node=node, ignore_names=False),
            binding=target.id if isinstance(target, ast.Name) else "",
            annotation=(ast.dump(node.annotation, include_attributes=False)
                        if isinstance(node, ast.AnnAssign) else ""),
            value_start=(PythonParser._fast_offset(source=source, offsets=offsets, line=value.lineno, col=value.col_offset) if value else None),
            value_end=(PythonParser._fast_offset(source=source, offsets=offsets, line=value.end_lineno or value.lineno, col=value.end_col_offset or 0) if value else None),
        )

    @staticmethod
    def _unit(*, source: str, node: ast.FunctionDef | ast.AsyncFunctionDef, parent: str, offsets: tuple[int, ...]) -> Unit:
        """Create a callable scope without losing annotation or decorator spans.

        Args:
            source: Python source text.
            node: Function AST node.
            parent: Containing class or function path.

        Returns:
            Callable unit with body statements.
        """
        beginning: int = min((d.lineno for d in node.decorator_list), default=node.lineno)
        first: ast.stmt = node.body[0]
        last: ast.stmt = node.body[-1]
        statements: tuple[Statement, ...] = tuple(
            PythonParser._statement(source=source, node=stmt, offsets=offsets) for stmt in node.body
        )
        parameters: tuple[str, ...] = tuple(
            a.arg for a in [*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs]
        )
        return Unit(
            kind="async_function" if isinstance(node, ast.AsyncFunctionDef) else "function",
            name=node.name,
            parent=parent,
            start=PythonParser._fast_offset(source=source, offsets=offsets, line=beginning, col=0),
            end=PythonParser._fast_offset(source=source, offsets=offsets, line=node.end_lineno or node.lineno, col=node.end_col_offset or 0),
            body_start=PythonParser._fast_offset(source=source, offsets=offsets, line=first.lineno, col=first.col_offset),
            body_end=PythonParser._fast_offset(source=source, offsets=offsets, line=last.end_lineno or last.lineno, col=last.end_col_offset or 0),
            statements=statements,
            fingerprint="|".join(stmt.shape for stmt in statements),
            signature=f"{type(node).__name__}:{len(parameters)}:{bool(node.args.vararg)}:{bool(node.args.kwarg)}",
            param_names=parameters,
            header_semantic="|".join((
                ast.dump(node.args, include_attributes=False),
                ast.dump(node.returns, include_attributes=False) if node.returns else "",
                *(ast.dump(item, include_attributes=False) for item in node.decorator_list),
            )),
        )

    def parse(self, *, source: str) -> Snapshot:
        """Parse a Python module into callable and statement identity graphs.

        Args:
            source: Python 3.13 source text.

        Returns:
            Snapshot; invalid syntax is returned as an explicit failure.
        """
        try:
            tree: ast.Module = ast.parse(source=source, type_comments=True)
        except (SyntaxError, ValueError) as error:
            return Snapshot(source=source, units=(), statements=(), valid=False, error=str(error))
        units: list[Unit] = []
        statements: list[Statement] = []
        starts: list[int] = [0]
        for line in source.splitlines(keepends=True):
            starts.append(starts[-1] + len(line))
        offsets: tuple[int, ...] = tuple(starts)

        def visit(*, nodes: list[ast.stmt], parent: str, inside_callable: bool) -> None:
            """Visit nested scopes without conflating method and class identity."""
            for node in nodes:
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    unit: Unit = self._unit(source=source, node=node, parent=parent, offsets=offsets)
                    units.append(unit)
                    visit(nodes=node.body, parent=unit.key, inside_callable=True)
                elif isinstance(node, ast.ClassDef):
                    visit(
                        nodes=node.body, parent=f"{parent}.{node.name}" if parent else node.name,
                        inside_callable=inside_callable,
                    )
                else:
                    if isinstance(node, (ast.Assign, ast.AnnAssign)):
                        stmt: Statement = self._statement(source=source, node=node, offsets=offsets)
                        if stmt.binding and not inside_callable:
                            units.append(Unit(
                                kind="assignment", name=stmt.binding, parent=parent,
                                start=PythonParser._fast_offset(source=source, offsets=offsets, line=node.lineno, col=0),
                                end=stmt.end, body_start=stmt.value_start or stmt.start,
                                body_end=stmt.value_end or stmt.end,
                                statements=(stmt,), fingerprint=stmt.shape,
                                signature="assignment",
                            ))
                    statements.append(self._statement(source=source, node=node, offsets=offsets))
                    for field, value in ast.iter_fields(node):
                        if field in {"body", "orelse", "finalbody"} and isinstance(value, list):
                            visit(
                                nodes=[item for item in value if isinstance(item, ast.stmt)],
                                parent=parent, inside_callable=inside_callable,
                            )
                        elif field == "handlers" and isinstance(value, list):
                            for handler in value:
                                if isinstance(handler, ast.ExceptHandler):
                                    visit(
                                        nodes=handler.body, parent=parent,
                                        inside_callable=inside_callable,
                                    )

        visit(nodes=tree.body, parent="", inside_callable=False)
        return Snapshot(
            source=source, units=tuple(units), statements=tuple(statements), valid=True
        )

    @staticmethod
    def rewrite_names(*, text: str, mapping: dict[str, str]) -> str:
        """Rewrite identifier tokens, excluding strings, comments and attributes.

        Args:
            text: Self-contained Python statement source text.
            mapping: Verified, non-colliding local spelling substitutions.

        Returns:
            Text with selected NAME tokens updated.
        """
        if not mapping:
            return text
        try:
            tree: ast.Module = ast.parse(source=text)
        except SyntaxError as error:
            msg: str = f"Cannot resolve identifier scopes in inserted Python code: {error}"
            raise ValueError(msg) from error
        locations: set[tuple[int, int]] = {
            (node.lineno, len(text.splitlines(keepends=True)[node.lineno - 1]
                              .encode(encoding="utf-8")[:node.col_offset].decode(encoding="utf-8")))
            for node in ast.walk(tree)
            if isinstance(node, ast.Name) and node.id in mapping
        }
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.name in mapping:
                msg = f"Renaming shadowed nested declaration {node.name} requires symbol resolution"
                raise ValueError(msg)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
                if any(arg.arg in mapping for arg in [*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs]):
                    msg = "Nested parameter shadows an identifier being renamed"
                    raise ValueError(msg)
        tokens: list[tokenize.TokenInfo] = list(
            tokenize.generate_tokens(readline=io.StringIO(text).readline)
        )
        return tokenize.untokenize([
            item._replace(string=mapping[item.string])
            if item.type == tokenize.NAME and item.start in locations
            else item for item in tokens
        ])
