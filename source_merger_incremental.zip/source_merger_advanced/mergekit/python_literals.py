"""Preserve tool line wrapping during independent Python literal edits."""

from __future__ import annotations

import ast
from collections.abc import Iterator

from mergekit.model import Replacement, Statement
from mergekit.python_parser import PythonParser


def _statement_node(*, source: str, record: Statement) -> ast.stmt | None:
    """Find the exact AST statement corresponding to a source-offset record.

    Args:
        source: Complete Python program text.
        record: Statement identity and offset record.

    Returns:
        Matching AST statement or None if it cannot be uniquely determined.
    """
    try:
        tree: ast.Module = ast.parse(source=source)
    except SyntaxError:
        return None
    matches: list[ast.stmt] = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.stmt)
        and PythonParser.offset(source=source, line=node.lineno, col=node.col_offset) == record.start
        and PythonParser.offset(
            source=source, line=node.end_lineno or node.lineno, col=node.end_col_offset or 0
        ) == record.end
    ]
    return matches[0] if len(matches) == 1 else None


def _fields(*, node: ast.AST) -> Iterator[tuple[str, ast.AST | list[ast.AST] | str | int | bool | None]]:
    """Yield semantic AST fields for syntax equivalence inspection.

    Args:
        node: Node to enumerate.

    Yields:
        Semantic field names and child values.
    """
    for name, value in ast.iter_fields(node):
        if name in {"ctx", "type_comment", "type_params", "annotation", "returns", "decorator_list"}:
            continue
        if isinstance(value, (ast.AST, list, str, int, bool)) or value is None:
            yield name, value


def literal_replacements(
    *,
    original_source: str,
    user_source: str,
    tool_source: str,
    original: Statement,
    user: Statement,
    tool: Statement,
) -> tuple[Replacement, ...] | None:
    """Transfer literal-only changes onto matching tool AST leaf positions.

    Args:
        original_source: Original module.
        user_source: User module.
        tool_source: Refactored module.
        original: Common-ancestor statement.
        user: Modified user statement.
        tool: Matching refactored statement.

    Returns:
        Source patches if every changed AST leaf is a safely tracked literal,
        or None when statement-level replacement is required.
    """
    base: ast.stmt | None = _statement_node(source=original_source, record=original)
    edited: ast.stmt | None = _statement_node(source=user_source, record=user)
    target: ast.stmt | None = _statement_node(source=tool_source, record=tool)
    if base is None or edited is None or target is None:
        return None
    changes: list[Replacement] = []

    def compare(*, old: ast.AST, own: ast.AST, latest: ast.AST) -> bool:
        """Check compatible AST shape and collect constant-only source edits."""
        if type(old) is not type(own) or type(old) is not type(latest):
            return False
        if isinstance(old, ast.Constant) and isinstance(own, ast.Constant) and isinstance(latest, ast.Constant):
            if old.value != own.value:
                if old.value != latest.value:
                    return False
                changes.append(Replacement(
                    PythonParser.offset(source=tool_source, line=latest.lineno, col=latest.col_offset),
                    PythonParser.offset(source=tool_source, line=latest.end_lineno or latest.lineno,
                                        col=latest.end_col_offset or 0),
                    ast.get_source_segment(source=user_source, node=own) or repr(own.value),
                    "literal",
                ))
            return True
        for (name, old_value), (user_name, own_value), (tool_name, latest_value) in zip(
            _fields(node=old), _fields(node=own), _fields(node=latest), strict=False,
        ):
            if name != user_name or name != tool_name:
                return False
            if isinstance(old_value, ast.AST):
                if not isinstance(own_value, ast.AST) or not isinstance(latest_value, ast.AST):
                    return False
                if not compare(old=old_value, own=own_value, latest=latest_value):
                    return False
            elif isinstance(old_value, list):
                if not isinstance(own_value, list) or not isinstance(latest_value, list):
                    return False
                if len(old_value) != len(own_value) or len(old_value) != len(latest_value):
                    return False
                for base_item, own_item, tool_item in zip(old_value, own_value, latest_value, strict=True):
                    if not isinstance(base_item, ast.AST) or not isinstance(own_item, ast.AST) or not isinstance(tool_item, ast.AST):
                        return False
                    if not compare(old=base_item, own=own_item, latest=tool_item):
                        return False
            elif old_value != own_value:
                return False
        return True

    if not compare(old=base, own=edited, latest=target) or not changes:
        return None
    return tuple(changes)
