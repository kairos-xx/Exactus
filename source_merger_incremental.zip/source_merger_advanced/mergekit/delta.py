"""Conservative mutation-budget checks for independently edited source forks."""

from __future__ import annotations

import ast
import difflib
from bisect import bisect_left
from collections import Counter
from collections.abc import Iterator
import io
import re
import tokenize
from dataclasses import dataclass
from typing import final

from mergekit.model import Language


@final
@dataclass(frozen=True, slots=True, kw_only=True)
class DeltaPolicy:
    """Limits for automatic reconciliation; exceeding a limit requires review.

    Attributes:
        max_user_changed_fraction: Largest permitted fraction of ancestor tokens changed.
        max_tool_changed_fraction: Largest permitted fraction of ancestor tokens changed.
        max_combined_changed_fraction: Largest combined changed fraction.
        max_user_inserted_tokens: Maximum number of user-added tokens per fork.
        max_user_replaced_tokens: Maximum number of user-replaced tokens per fork.
        max_user_deleted_tokens: Maximum number of user-deleted tokens per fork.
        max_user_edit_events: Maximum number of independent user edit regions.
        max_user_tokens_per_second: Burst-size limit when elapsed time is known.
        short_fork_seconds: Interval at which burst diagnostics are enabled.
        min_identity_confidence: Minimum identity score for an automatic merge.
        min_identity_margin: Minimum separation between best and runner-up match.
    """

    max_user_changed_fraction: float = 1.0
    max_tool_changed_fraction: float = 1.0
    max_combined_changed_fraction: float = 2.0
    max_user_inserted_tokens: int = 20000
    max_user_replaced_tokens: int = 20000
    max_user_deleted_tokens: int = 20000
    max_user_edit_events: int = 500
    max_user_tokens_per_second: float = 10000.0
    short_fork_seconds: float = 5.0
    min_identity_confidence: float = 0.72
    min_identity_margin: float = 0.09


@final
@dataclass(frozen=True, slots=True)
class DeltaMetrics:
    """Lexical delta measurements, independent of formatting and line numbers.

    Attributes:
        ancestor_tokens: Number of ancestor tokens.
        changed_fraction: Fraction of ancestor tokens affected, capped at one.
        inserted_tokens: Tokens inserted into the fork.
        replaced_tokens: Original tokens replaced by the fork.
        deleted_tokens: Tokens deleted from the ancestor.
        edit_events: Number of non-equal token diff regions.
    """

    ancestor_tokens: int
    changed_fraction: float
    inserted_tokens: int
    replaced_tokens: int
    deleted_tokens: int
    edit_events: int


def _tokens(*, source: str, language: Language) -> tuple[str, ...]:
    """Extract meaningful tokens without treating line wrapping as mutation."""
    if language == "python":
        try:
            return tuple(
                f"{token.type}:{token.string}"
                for token in tokenize.generate_tokens(readline=io.StringIO(source).readline)
                if token.type not in {
                    tokenize.NL, tokenize.NEWLINE, tokenize.INDENT,
                    tokenize.DEDENT, tokenize.ENDMARKER, tokenize.ENCODING,
                }
            )
        except (SyntaxError, tokenize.TokenError, IndentationError):
            return tuple(source.split())
    return tuple(re.findall(
        r"(?:[A-Za-z_$][\w$-]*|\d+(?:\.\d+)?|===|!==|=>|==|!=|<=|>=|\S)",
        source,
    ))


def _changed_lines(
    *, before: list[str], after: list[str]
) -> Iterator[tuple[str, int, int, int, int]]:
    """Yield bounded edit chunks using O(n log n) unique-line anchors.

    Unique common lines provide deterministic anchors under reordering. Long
    unmatched spans are emitted intact to avoid quadratic fuzzy matching.
    Repeated content is reduced through exact common-prefix/suffix trimming.
    """
    former: Counter[str] = Counter(before)
    latter: Counter[str] = Counter(after)
    positions: dict[str, int] = {
        line: index for index, line in enumerate(after)
        if latter[line] == 1 and former[line] == 1
    }
    candidates: list[tuple[int, int]] = [
        (index, positions[line])
        for index, line in enumerate(before) if line in positions
    ]
    ends: list[int] = []
    tail_indices: list[int] = []
    parents: list[int] = [-1] * len(candidates)
    for index, (_, location) in enumerate(candidates):
        position: int = bisect_left(ends, location)
        if position:
            parents[index] = tail_indices[position - 1]
        if position == len(ends):
            ends.append(location)
            tail_indices.append(index)
        else:
            ends[position] = location
            tail_indices[position] = index
    anchors: list[tuple[int, int]] = []
    if tail_indices:
        cursor: int = tail_indices[-1]
        while cursor >= 0:
            anchors.append(candidates[cursor])
            cursor = parents[cursor]
        anchors.reverse()
    left: int = 0
    right: int = 0
    for anchor_old, anchor_new in (*anchors, (len(before), len(after))):
        old_end: int = anchor_old
        new_end: int = anchor_new
        old_begin: int = left
        new_begin: int = right
        while (
            old_begin < old_end and new_begin < new_end
            and before[old_begin] == after[new_begin]
        ):
            old_begin += 1
            new_begin += 1
        while (
            old_begin < old_end and new_begin < new_end
            and before[old_end - 1] == after[new_end - 1]
        ):
            old_end -= 1
            new_end -= 1
        if old_begin < old_end or new_begin < new_end:
            if old_end - old_begin + new_end - new_begin <= 256:
                for action, i1, i2, j1, j2 in difflib.SequenceMatcher(
                    isjunk=None, a=before[old_begin:old_end],
                    b=after[new_begin:new_end], autojunk=True,
                ).get_opcodes():
                    if action != "equal":
                        yield (
                            action, old_begin + i1, old_begin + i2,
                            new_begin + j1, new_begin + j2,
                        )
            else:
                yield (
                    "replace" if old_begin < old_end and new_begin < new_end
                    else "delete" if old_begin < old_end else "insert",
                    old_begin, old_end, new_begin, new_end,
                )
        left = anchor_old + 1
        right = anchor_new + 1


def measure(*, original: str, changed: str, language: Language) -> DeltaMetrics:
    """Measure fork deltas using line-local token matches with bounded work.

    Unchanged lines never participate in token-level diff. Large unmatched
    chunks are conservatively counted as full replacements rather than
    exposing an O(n²) repetitive-token comparison to an interactive editor.
    """
    if original == changed:
        return DeltaMetrics(0, 0.0, 0, 0, 0, 0)
    ancestor: tuple[str, ...] = _tokens(source=original, language=language)
    fork: tuple[str, ...] = _tokens(source=changed, language=language)
    if language == "python" and (
        ancestor == fork or (
            len(fork) <= len(ancestor) + 64
            and len(ancestor) <= len(fork) + 64
            and tuple(
                value for index, value in enumerate(ancestor)
                if not (value == "55:," and index + 1 < len(ancestor) and ancestor[index + 1] in {"55:)", "55:]", "55:}"})
            ) == tuple(
                value for index, value in enumerate(fork)
                if not (value == "55:," and index + 1 < len(fork) and fork[index + 1] in {"55:)", "55:]", "55:}"})
            )
        )
    ):
        try:
            if (
                ast.dump(ast.parse(source=original), include_attributes=False)
                == ast.dump(ast.parse(source=changed), include_attributes=False)
                and tuple(re.findall(r"(?m)#.*$", original))
                == tuple(re.findall(r"(?m)#.*$", changed))
            ):
                return DeltaMetrics(len(ancestor), 0.0, 0, 0, 0, 0)
        except SyntaxError:
            pass
        # Identical lexical tokens can still have different Python semantics:
        # indentation, trailing tuple commas and scope boundaries matter.
        # Charge such unresolvable cases conservatively to the mutation budget.
        return DeltaMetrics(
            ancestor_tokens=len(ancestor), changed_fraction=1.0,
            inserted_tokens=len(fork), replaced_tokens=len(ancestor),
            deleted_tokens=0, edit_events=1,
        )
    if language != "python" and ancestor == fork:
        return DeltaMetrics(len(ancestor), 0.0, 0, 0, 0, 0)
    replaced: int = 0
    deleted: int = 0
    inserted: int = 0
    events: int = 0
    before: list[str] = original.splitlines(keepends=True)
    after: list[str] = changed.splitlines(keepends=True)
    for kind, start, end, new_start, new_end in _changed_lines(
        before=before, after=after
    ):
        if kind == "equal":
            continue
        if kind in {"delete", "insert"}:
            amount: int = len(_tokens(source="".join(before[start:end]), language=language))
            additional: int = len(_tokens(source="".join(after[new_start:new_end]), language=language))
            deleted += amount
            inserted += additional
            events += 1
            continue
        old_tokens: tuple[str, ...] = _tokens(
            source="".join(before[start:end]), language=language
        )
        new_tokens: tuple[str, ...] = _tokens(
            source="".join(after[new_start:new_end]), language=language
        )
        if len(old_tokens) + len(new_tokens) > 4096:
            replaced += len(old_tokens)
            inserted += len(new_tokens)
            events += max(1, end - start, new_end - new_start)
            continue
        for action, i1, i2, j1, j2 in difflib.SequenceMatcher(
            isjunk=None, a=old_tokens, b=new_tokens, autojunk=True,
        ).get_opcodes():
            if action == "equal":
                continue
            events += 1
            if action == "replace":
                replaced += i2 - i1
                inserted += j2 - j1
            elif action == "delete":
                deleted += i2 - i1
            elif action == "insert":
                inserted += j2 - j1
    return DeltaMetrics(
        ancestor_tokens=len(ancestor),
        changed_fraction=min(
            1.0, (replaced + deleted + inserted) / max(1, len(ancestor))
        ),
        inserted_tokens=inserted, replaced_tokens=replaced,
        deleted_tokens=deleted, edit_events=events,
    )


def violations(
    *, user: DeltaMetrics, tool: DeltaMetrics, policy: DeltaPolicy,
    elapsed_seconds: float | None,
) -> tuple[str, ...]:
    """Explain why a lexical delta is too large for automatic reconciliation."""
    findings: list[str] = []
    limits: tuple[tuple[str, float, float], ...] = (
        ("user changed fraction", user.changed_fraction, policy.max_user_changed_fraction),
        ("tool changed fraction", tool.changed_fraction, policy.max_tool_changed_fraction),
        ("combined changed fraction", user.changed_fraction + tool.changed_fraction, policy.max_combined_changed_fraction),
        ("user inserted tokens", user.inserted_tokens, policy.max_user_inserted_tokens),
        ("user replaced tokens", user.replaced_tokens, policy.max_user_replaced_tokens),
        ("user deleted tokens", user.deleted_tokens, policy.max_user_deleted_tokens),
        ("user edit regions", user.edit_events, policy.max_user_edit_events),
    )
    findings.extend(
        f"{name}: {actual:.4g} exceeds {maximum:.4g}"
        for name, actual, maximum in limits if actual > maximum
    )
    if elapsed_seconds is not None:
        if elapsed_seconds < 0:
            findings.append("Fork elapsed time cannot be negative")
        elif elapsed_seconds <= policy.short_fork_seconds and (
            user.inserted_tokens + user.replaced_tokens + user.deleted_tokens
        ) / max(elapsed_seconds, 0.001) > policy.max_user_tokens_per_second:
            findings.append("Short-fork edit burst exceeds configured token-rate limit; pasted changes require review")
    return tuple(findings)
