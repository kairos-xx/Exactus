"""Isolate Python import header refactoring from unrelated concurrent edits."""

from __future__ import annotations

import ast
import io
import tokenize
from dataclasses import dataclass
from typing import final

from mergekit.model import MergeConflict, Replacement


type _Binding = tuple[str, str, str, str]


@final
@dataclass(frozen=True, slots=True)
class ImportRegion:
    """Contiguous, safely isolatable module import header.

    Attributes:
        start: Start of first module-level import line.
        end: End of last import line including its newline.
        text: Preserved source of the entire import region.
        bindings: Full alias identities from the region.
        aliases: Original import nodes with their alias names.
    """

    start: int
    end: int
    text: str
    bindings: frozenset[_Binding]
    aliases: tuple[tuple[_Binding, str], ...]


def _binding(*, node: ast.Import | ast.ImportFrom, alias: ast.alias) -> _Binding:
    """Return an import binding including its alias and relative module level.

    Args:
        node: Containing import statement.
        alias: Imported name within the statement.

    Returns:
        Stable lexical identity for one import binding.
    """
    if isinstance(node, ast.Import):
        return ("import", "", alias.name, alias.asname or "")
    return ("from", "." * node.level + (node.module or ""), alias.name, alias.asname or "")


def collect(*, source: str) -> ImportRegion | None:
    """Identify a top-level module import region safe to isolate.

    Args:
        source: Complete Python module text.

    Returns:
        Header import data, or None for interleaved executable code.
    """
    try:
        tree: ast.Module = ast.parse(source=source)
    except SyntaxError:
        return None
    nodes: list[ast.stmt] = list(tree.body)
    imports: list[ast.Import | ast.ImportFrom] = []
    started: bool = False
    ended: bool = False
    for index, node in enumerate(nodes):
        if index == 0 and isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            continue
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            if ended:
                return None
            imports.append(node)
            started = True
        elif started:
            ended = True
    if not imports:
        return None
    lines: list[str] = source.splitlines(keepends=True)
    first: int = imports[0].lineno - 1
    last: int = imports[-1].end_lineno or imports[-1].lineno
    start: int = sum(map(len, lines[:first]))
    end: int = sum(map(len, lines[:last]))
    bindings: list[tuple[_Binding, str]] = []
    for node in imports:
        for alias in node.names:
            key: _Binding = _binding(node=node, alias=alias)
            raw: str = (
                f"import {alias.name}" if isinstance(node, ast.Import)
                else f"from {'.' * node.level}{node.module or ''} import {alias.name}"
            ) + (f" as {alias.asname}" if alias.asname else "")
            bindings.append((key, raw))
    return ImportRegion(
        start=start, end=end, text=source[start:end],
        bindings=frozenset(key for key, _raw in bindings),
        aliases=tuple(bindings),
    )


def reconcile(
    *, original: ImportRegion, user: ImportRegion, tool: ImportRegion,
) -> tuple[str | None, tuple[MergeConflict, ...]]:
    """Apply user import additions atop the tool's reorganized import header.

    Args:
        original: Original import header.
        user: User import header.
        tool: Tool import header.

    Returns:
        Complete merged header and unresolved import conflicts.
    """
    old_comments: tuple[str, ...] = tuple(
        token.string for token in tokenize.generate_tokens(
            readline=io.StringIO(original.text).readline
        ) if token.type == tokenize.COMMENT
    )
    user_comments: tuple[str, ...] = tuple(
        token.string for token in tokenize.generate_tokens(
            readline=io.StringIO(user.text).readline
        ) if token.type == tokenize.COMMENT
    )
    if user_comments != old_comments:
        return None, (MergeConflict(
            "unsupported_transformation", "imports",
            "User changed import-region comments; regrouping cannot safely attach them",
        ),)
    removed: frozenset[_Binding] = original.bindings - user.bindings
    additions: frozenset[_Binding] = user.bindings - original.bindings
    if removed & tool.bindings:
        return None, (MergeConflict(
            "concurrent_change", "imports",
            "User removed imports that the tool retained; dependency references require validation",
        ),)
    added: list[str] = []
    for name, source in user.aliases:
        if name in additions and name not in tool.bindings:
            added.append(source)
    if not added:
        return tool.text, ()
    future: list[str] = [line for line in added if line.startswith("from __future__ import ")]
    ordinary: list[str] = [line for line in added if line not in future]
    lines: str = tool.text.rstrip("\r\n")
    if future:
        # A new future import must follow any module docstring and precede all
        # ordinary imports. Avoid altering already valid future-header ordering.
        lines = "\n".join(future) + "\n" + lines
    if ordinary:
        lines += "\n" + "\n".join(ordinary)
    return lines + "\n", ()


def hide(*, source: str, region: ImportRegion) -> str:
    """Replace the entire import region with an ancestor-stable marker.

    Args:
        source: Source snapshot.
        region: Contiguous import header.

    Returns:
        Source with unmatched import grouping removed from textual diff3.
    """
    marker: Replacement = Replacement(
        region.start, region.end, "# MERGEKIT_IMPORT_BLOCK\n", "imports"
    )
    return source[:marker.start] + marker.text + source[marker.end:]
