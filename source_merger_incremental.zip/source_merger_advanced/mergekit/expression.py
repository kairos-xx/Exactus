"""Conservative expression-tree reconciliation inside matched Python statements."""

from __future__ import annotations

import ast

from mergekit.model import Replacement
from mergekit.python_parser import PythonParser


def project_python_expression(
    *, original: str, user: str, tool: str, tool_start: int,
    mapping: dict[str, str], scope: str,
) -> tuple[Replacement, ...] | None:
    """Project independent user expression mutations into a refactored expression.

    Existing tool-side changes at other expression paths are retained. The
    algorithm rejects competing edits to a shared subtree and any node shape
    that cannot be aligned without guessing. It never evaluates source code.

    Args:
        original: Ancestor RHS/return expression text.
        user: User-edited expression text.
        tool: Tool-refactored expression text.
        tool_start: Absolute offset of the target expression in the tool file.
        mapping: Proven old-to-new identifier spellings.
        scope: Location recorded for proposed patches.

    Returns:
        Nonoverlapping source-span patches; None for ambiguous mutations.

    Raises:
        ValueError: Identifier rewriting or expression parsing was unsafe.
    """
    old_text: str = PythonParser.rewrite_names(text=original, mapping=mapping)
    user_text: str = PythonParser.rewrite_names(text=user, mapping=mapping)
    try:
        base: ast.expr = ast.parse(source=old_text, mode="eval").body
        edited: ast.expr = ast.parse(source=user_text, mode="eval").body
        target: ast.expr = ast.parse(source=tool, mode="eval").body
    except (SyntaxError, ValueError) as error:
        msg: str = f"Cannot compare changed Python expressions safely: {error}"
        raise ValueError(msg) from error
    patches: list[Replacement] = []

    def stable(*, left: ast.AST, right: ast.AST) -> bool:
        """Compare expression semantics without source coordinates."""
        return ast.dump(left, include_attributes=False) == ast.dump(
            right, include_attributes=False
        )

    def emit(*, own: ast.AST, latest: ast.AST) -> bool:
        """Stage a user subtree at the corresponding refactored source span."""
        if not isinstance(own, ast.expr) or not isinstance(latest, ast.expr):
            return False
        snippet: str | None = ast.get_source_segment(source=user_text, node=own)
        if snippet is None:
            return False
        patches.append(Replacement(
            start=tool_start + PythonParser.offset(
                source=tool, line=latest.lineno, col=latest.col_offset
            ),
            end=tool_start + PythonParser.offset(
                source=tool, line=latest.end_lineno or latest.lineno,
                col=latest.end_col_offset or 0,
            ),
            text=snippet, scope=scope,
        ))
        return True

    def reconcile(*, old: ast.AST, own: ast.AST, latest: ast.AST) -> bool:
        """Descend to the smallest independent mutated expression subtree."""
        if stable(left=old, right=own):
            return True
        if stable(left=own, right=latest):
            return True
        unchanged: bool = stable(left=old, right=latest)
        if type(old) is not type(own) or type(old) is not type(latest):
            return emit(own=own, latest=latest) if unchanged else False
        initial: int = len(patches)
        old_fields: dict[str, ast.AST | list[ast.AST] | str | int | bool | None] = dict(
            ast.iter_fields(old)
        )
        own_fields: dict[str, ast.AST | list[ast.AST] | str | int | bool | None] = dict(
            ast.iter_fields(own)
        )
        tool_fields: dict[str, ast.AST | list[ast.AST] | str | int | bool | None] = dict(
            ast.iter_fields(latest)
        )
        if old_fields.keys() != own_fields.keys() or old_fields.keys() != tool_fields.keys():
            return emit(own=own, latest=latest) if unchanged else False
        def descend() -> bool:
            """Traverse child fields, rejecting unalignable parallel edits."""
            for name, before in old_fields.items():
                after: ast.AST | list[ast.AST] | str | int | bool | None = own_fields[name]
                current: ast.AST | list[ast.AST] | str | int | bool | None = tool_fields[name]
                if isinstance(before, ast.AST):
                    if not isinstance(after, ast.AST) or not isinstance(current, ast.AST):
                        return False
                    if not reconcile(old=before, own=after, latest=current):
                        return False
                elif isinstance(before, list):
                    if not isinstance(after, list) or not isinstance(current, list):
                        return False
                    if len(before) != len(after) or len(before) != len(current):
                        return False
                    for first, second, third in zip(before, after, current, strict=True):
                        if not isinstance(first, ast.AST) or not isinstance(second, ast.AST) or not isinstance(third, ast.AST):
                            if first != second:
                                return False
                        elif not reconcile(old=first, own=second, latest=third):
                            return False
                elif before != after and after != current:
                    return False
            return True
        if descend():
            return True
        if unchanged:
            del patches[initial:]
            return emit(own=own, latest=latest)
        return False

    return tuple(patches) if reconcile(old=base, own=edited, latest=target) else None
