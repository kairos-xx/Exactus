# MergeKit: tracked, conservative three-way source merge

MergeKit reconciles three **immutable snapshots** of the same source file:

1. `original`: the common ancestor before either fork was modified;
2. `user_edited`: what the user did in an editor while refactoring ran;
3. `tool_refactored`: what the tool independently produced from `original`.

The tool's refactored source is used as the **structural destination**. User changes are projected onto surviving syntax identities, not onto original line numbers. The process reports conflicts rather than choosing a branch based on guesswork. It never writes the input files.

This implementation is substantially stronger than a line-based merge, but it is **not a proof of semantic equivalence**. Renames, extraction, scope changes, and cross-file transformations cannot be resolved universally without editor symbol tables, project-wide binding analysis, or explicit transformation provenance.

## Python API

```python
from pathlib import Path

from mergekit import SourceMerger

original = Path("snapshots/base.py").read_text(encoding="utf-8")
user_edited = Path("snapshots/editor.py").read_text(encoding="utf-8")
tool_refactored = Path("snapshots/refactored.py").read_text(encoding="utf-8")

result = SourceMerger(
    original=original,
    user_edited=user_edited,
    tool_refactored=tool_refactored,
    language="python",
).merge()

if result.success and result.source is not None:
    Path("snapshots/merged-candidate.py").write_text(
        data=result.source,
        encoding="utf-8",
    )
else:
    for conflict in result.conflicts:
        print(conflict.kind, conflict.scope, conflict.detail)

for match in result.matches:
    print(match.original, "->", match.changed, match.branch, match.confidence)

for change in result.applied_changes:
    print(change.operation, change.scope, change.detail)
```

`language` also accepts `"javascript"`, `"typescript"`, `"css"` and `"html"`. The alias `TrackedSourceMerger` exposes the same `.merge()` return object, `MergeResult`. Previous import paths `mergekit.merge` and `mergekit.advanced` remain available, but the older nested `result.merge.success` response shape is replaced by `result.success`.

`MergeResult` fields are `source: str | None`, `success: bool`, `syntax_valid: bool | None`, `conflicts`, `matches`, and `applied_changes`. On *any* unresolved conflict, `source` is `None`, preventing accidental direct writes.

## Supported mutation reconciliation

| Mutation | Implemented strategy |
|---|---|
| Line number movement / whitespace / wrapping | Syntax offsets and ancestor placeholders; preserve tool formatting on unchanged statements and certain literal-only changes |
| Python function/method reorder | One-to-one identity matching; reconstruct in the refactored order |
| Python method/function rename or relocation | AST similarity and owner-independent tracking, with explicit ambiguity checks |
| Python parameter rename by tool | AST-aware rewriting of user-added references, not strings, comments, keyword argument names, or attributes |
| Python local assignment rename by tool | Transfer user additions/replacements to the new local symbol when the binding correspondence is unique |
| Python type annotations added by tool | Keep type annotations while merging independent RHS and body modifications |
| Python constants moved into a `@final` class | Match assignments through value/shape and binding, update their RHS inside the new class |
| Statement extraction into a new helper | Search all refactored statements for a unique matching ancestor syntax identity |
| Python import regrouping/reordering | Isolate module import header and independently merge user import additions, retaining tool grouping |
| JavaScript regular function → arrow | TypeScript AST identifies the same body; expands expression arrows to blocks when extra user statements must be inserted |
| JS/TS function/parameter rename | AST binding-position matching; rewritten references exclude strings, comments, regexes, property names and ambiguous shorthand bindings |
| CSS selector / custom property rename | PostCSS rule/declaration matching; values and `var(--token)` references mapped to tool identifiers |
| CSS rule relocation | Preserve refactored rule ordering, reconcile individual declarations |
| HTML element relocation | Track ID-bearing element subtrees and merge independent child markup edits |
| HTML attributes added/changed on either side | Attribute-level three-way reconciliation while retaining the tool's attribute ordering and additional attributes |
| Conflicting semantic modifications | Reject without generating a candidate source |
| Missing parser or malformed source | Fail closed with `parse_error` or `validation_error` |

### Explicit limits

- **No unqualified semantic guarantees.** Source parsing cannot prove that runtime behavior is unchanged. Passing syntax checks is necessary, not sufficient.
- Binding and rename tracking are **local and heuristic**. Unsupported or ambiguous cross-file symbol references are conflicts. New user-side renames and signature edits are deliberately rejected when automatic reference migration cannot be established.
- Python statement matching is AST-based. More complex extraction, inlining, function decomposition, generated wrappers, changes to control-flow nesting, and simultaneous changes to the same expression may require manual intervention. Exact structural identity is not guaranteed in arbitrary clone-heavy source.
- Python user edits to annotations, decorators, signatures, or comments in tracked callables are conservative conflicts unless they already agree with the tool. Tool-added annotations are preserved for supported user body/RHS edits.
- JavaScript/TypeScript parsing uses the TypeScript parser, not a type checker. TypeScript errors outside grammar validation require project type checking. AST-aware JS name substitution rejects shorthand properties or definitions with ambiguous bindings.
- HTML subtree body edits use conflict-aware textual reconciliation after the enclosing element is structurally matched. Deep simultaneous DOM rewrites are not automatically proven safe. HTML elements without stable IDs fall back to textual matching.
- CSS custom-property spelling must be grounded in matching declarations; the engine does not automatically rewrite an entire project's dependent stylesheets.
- Import block normalization is limited to ordinary, contiguous Python module headers. Removals that the tool retains or changed import comments cause review conflicts. Imports interspersed with executable code are not normalized.
- This is a **single-file** merger and intentionally avoids touching live editor buffers, running source files, or other files. Source-reference migrations across a project need project-wide symbol resolution and a versioned editor transaction.
- This engine is not a lossless CST editor for all languages, and cannot track every structurally unrelated change. Always run language checkers and tests on accepted results.

## Requirements

Python 3.13 or newer. The Python engine itself has no third-party Python runtime requirements.

External language frontends:

- **Git** for `git merge-file` (all languages when there are unmatched changes).
- **Node.js 18+** and **TypeScript** for JavaScript and TypeScript.
- **Node.js 18+** and **PostCSS** for CSS.
- **Python standard library `html.parser`** for HTML.

The Node frontend attempts local Node module resolution first, then `npm root -g`; it never installs packages and never executes the source being merged.

Typical setup when those tools are available locally:

```bash
python3.13 -m pip install .
node --version
git --version
node --check mergekit/parse_node.cjs
python3.13 -m pytest tests -q
```

You can use this source tree directly with `PYTHONPATH=.`. To extract the ZIP into a project root, use:

```bash
unzip -o source_merger_advanced.zip -d /path/to/project
```

## High-throughput editor sessions (v0.3.0)

The matcher is now hierarchical down to **indexed statements and Python
expression subtrees**. On the Python path, independent changes to distinct
arguments, binary-expression operands, and literal leaves can be combined.
The engine also tracks certain statements independently modified by the tool
and moved into a helper, or assignments moved into a typed `@final` class.
Competing edits at the same AST path, or indistinguishable candidates, still
return an explicit conflict.

Use one **session-owned** `SnapshotCache` across editor notifications:

```python
from mergekit import SnapshotCache, SourceMerger

session = SnapshotCache(max_snapshots=24, max_matches=48)

# The next code block may run repeatedly, including after a 5-second edit fork.
result = SourceMerger(
    original=ancestor_source,
    user_edited=current_editor_buffer,
    tool_refactored=completed_refactor,
    language="python",
    snapshot_cache=session,
).merge()

if result.success and result.source is not None:
    candidate_source = result.source
else:
    conflicts = result.conflicts

print(session.stats)
```

The cache is explicit and bounded, keyed by complete-source SHA-256 digests,
and shared **only within that session**. It memoizes source parsing, fork delta
metrics, and identity tracking. Fork labels distinguish user and tool updates;
changing the ancestor invalidates partial-reparse predecessors.

### Incremental parse boundary

Python partial reparse currently supports a source change provably confined to
an **isolated top-level function body**, without nested declaration movement.
Unchanged source units are reused and their offsets shifted. Renames, added
functions, changed decorators, edits outside that body, or ambiguous boundary
changes go through the full parser. A malformed new version cannot reuse a
previous valid status. There is no assumption that a five-second typing window
is a small change: snapshots are compared by actual bytes and syntax.

For JavaScript/TypeScript/CSS, cold snapshots use **one Node process per batch**
(up to the requested snapshots), then exact snapshots are reused from cache.
These languages do **not** yet have partial AST reparsing. HTML has exact-source
caching but not incremental HTML subtree parsing.

### Performance changes

- Indexed statement lookup uses a prebuilt fingerprint dictionary and
  parent-scope indexes. Changed call expressions are retrieved by named callee
  before bounded fuzzy comparison.
- A long, unmatchable expression is rejected rather than given an unbounded
  edit-distance budget.
- Unique-line anchors and bounded token hunks avoid quadratic diff behavior
  on repeated code. Oversized unmatched chunks are conservatively charged to
  the mutation budget; this can reject a safe merge but cannot quietly waive
  the budget for a large ambiguous change.
- Source-span edits and declaration placeholder expansion use linear-pass
  reconstruction rather than repeated whole-file string rebuilding.
- Parser line offsets are precomputed, eliminating repeated whole-file scans
  for each AST statement.
- `DeltaPolicy.min_identity_confidence` and
  `DeltaPolicy.min_identity_margin` are now used by the matcher; the matching
  cache keys include these settings.

Run `python -m benchmarks.benchmark_merger` for reproducible **end-to-end**
measurements. The previously quoted declaration-matcher-only microbenchmarks
must not be treated as end-to-end merge latency.

**Safety limit:** cached parse trees and AST matches are not a compiler symbol
resolver. Cross-file reference edits, scope capture, deep simultaneous
extraction/inlining, and arbitrary JS symbol migration still require stronger
language-server provenance or a review conflict. Editor writes require a real
version-aware compare-and-swap or editor transaction.

## Editor safety and TOCTOU

The class never writes to live files. If an editor integration uses it, capture the original file *before* starting automated refactoring. At the end, retrieve the editor's latest versioned contents, call the merger, validate and present the candidate, and commit only if the editor's version has not changed.

A hash check followed by `os.replace` is **not** an atomic conditional update against unrelated writers. A production editor integration must use the editor's version-aware update mechanism, a shared lock respected by all writers, or another genuine compare-and-swap transaction. On a concurrent update, re-read and re-merge rather than overwrite.

## Validation status

The delivered suite contains tested cases covering Python rename/reorder/annotations, typed constants, moved statements, JavaScript arrows, TypeScript types, CSS selectors/variables, HTML movement/attributes, import additions, lexical safety, and conflict detection.

See `VALIDATION.md` for exact observed check results and unavailable validation gates. No coverage percentage is asserted.

## Mutation delta and five-second editing window

The merger now applies a **configurable lexical mutation budget** before structural reconciliation. It measures each fork independently against the original snapshot, not against the other fork. This avoids confusing tool-side reformatting with user edits. Python formatting-only AST-equivalent changes (including wrapping and optional trailing commas) do not consume the lexical budget when comments are unchanged.

```python
from mergekit import DeltaPolicy, SourceMerger, measure

result = SourceMerger(
    original=original_source,
    user_edited=user_source,
    tool_refactored=refactored_source,
    language="python",
    fork_elapsed_seconds=5.0,
    delta_policy=DeltaPolicy(
        max_user_inserted_tokens=300,
        max_user_replaced_tokens=150,
        max_user_deleted_tokens=150,
        max_user_edit_events=30,
        max_user_tokens_per_second=500.0,
        min_identity_confidence=0.72,
        min_identity_margin=0.09,
    ),
).merge()
```

When a budget is exceeded, `success=False`, `source=None`, and conflicts include `delta_exceeded`. The 5-second interval is **not a reason to discard changes**: users can paste entire files instantly. Elapsed time is an optional burst-risk signal, never a substitute for comparing the actual snapshots. The default budget is deliberately permissive to avoid rejecting small files; tune it for your editor and project. The `min_identity_confidence` and `min_identity_margin` fields now configure the indexed identity matcher, and are included in matching-cache keys. Lexical delta is a risk gate, not a proof that a merge preserves behavior. For strict production use, require AST/CST reconciliation and validation in addition to these limits.

## Indexed hierarchical matcher (performance upgrade)

The identity matcher now resolves declarations in stages: unique qualified-name
matches, unique syntax fingerprints (including renamed/moved declarations), and
bounded fuzzy candidates retrieved through indexes of name, signature, and
lexical parent. Matched parent declarations supply aliases for renamed classes.
The matcher does **not** calculate a similarity score for every possible pair.
Ambiguous fingerprint groups and excessive fuzzy candidate sets are rejected
rather than silently truncated or guessed. This makes typical exact/fingerprint
matching near-linear in the number of declarations; pathological duplicate
names/signatures can still increase memory or work and are handled conservatively.

A synthetic benchmark on this runtime matched 5,000 independently renamed and
reordered declarations in approximately 0.02 seconds **for tracking only**.
This excludes parsing, subprocess startup, statement reconciliation, and
validation. It is not a guarantee of end-to-end latency. Python now supports guarded, session-owned incremental function-body reparsing;
all supported languages have bounded snapshot caches.
