# Studio styles

These modules are imported in numeric cascade order by `../editor.css`. The
split keeps each interface area independently lintable while preserving the
rendered order of the original stylesheet.

Import order is the cascade, not the file number: `28-foundation.css` is
imported before `26-edit-workspace.css` so element defaults come first, and
`23-responsive-docks.css` keeps the generic `[hidden][hidden]` rule. A server
test checks that every imported stylesheet is served and none is orphaned.

## Directory contents

- `01-tokens.css` — Shared Studio design tokens.
- `02-shell.css` — Application shell and global controls.
- `03-panels.css` — Workspace and panel foundations.
- `04-dock-resizers.css` — Dock sizing controls.
- `05-flow-nodes.css` — Flow graph nodes and connectors.
- `06-screenshots.css` — Screenshot and action-library surfaces.
- `07-connections.css` — Connection and target controls.
- `08-inspector.css` — Inspector content and code displays.
- `09-forms.css` — Forms, fields, and action editors.
- `10-data-tables.css` — Tables and tabular panels.
- `11-composition.css` — Flow composition details.
- `12-responsive-base.css` — Base responsive adaptations.
- `13-timeline.css` — Timeline tracks and clips.
- `14-dialogs.css` — Dialog and preview surfaces.
- `15-actions.css` — Action controls and status treatments.
- `16-command-palette.css` — Command palette and workspace surface shell.
- `17-workspace-surfaces.css` — Workspace view layouts.
- `18-surface-controls.css` — Profile, comparison, and assertion controls.
- `19-control-specimens.css` — Control specimens and dock-zone foundations.
- `20-dock-groups.css` — Nested dock groups.
- `21-panel-docking.css` — Panel drag, split, and resize behavior.
- `22-dock-chrome.css` — Compact headers and dock chrome.
- `23-responsive-docks.css` — Final responsive dock adaptations.
- `28-foundation.css` — Element-level control defaults and icon masks (layered).
- `29-tokens.css` — Tonal grey ladder, semantic aliases, selection policy and scrollbars.
- `30-chrome.css` — Identity row, workspace sections, transport and status bar.
- `31-panels.css` — Panel headers, panel tools, the dock menu and the flow tree.
- `32-steps.css` — Step rows with drag grip and drop line, tabs and empty state.
- `33-sidebars.css` — Test browser, disclosure rows and the Properties form.
- `34-timeline.css` — Video-editor timeline header, ruler, lanes and clips.
- `35-dock-grid.css` — Dock grid, collapsed bars, resize handles and drop preview.
- `36-responsive.css` — Container-query and window-width adaptations.

<!-- exactus:inventory:start -->
## Directory contents

### Files

- [`01-tokens.css`](01-tokens.css) — Provide 01 tokens css content.
- [`02-shell.css`](02-shell.css) — Provide 02 shell css content.
- [`03-panels.css`](03-panels.css) — Provide 03 panels css content.
- [`04-dock-resizers.css`](04-dock-resizers.css) — Provide 04 dock resizers css content.
- [`05-flow-nodes.css`](05-flow-nodes.css) — Provide 05 flow nodes css content.
- [`06-screenshots.css`](06-screenshots.css) — Provide 06 screenshots css content.
- [`07-connections.css`](07-connections.css) — Provide 07 connections css content.
- [`08-inspector.css`](08-inspector.css) — Provide 08 inspector css content.
- [`09-forms.css`](09-forms.css) — Provide 09 forms css content.
- [`10-data-tables.css`](10-data-tables.css) — Provide 10 data tables css content.
- [`11-composition.css`](11-composition.css) — Provide 11 composition css content.
- [`12-responsive-base.css`](12-responsive-base.css) — Provide 12 responsive base css content.
- [`13-timeline.css`](13-timeline.css) — Provide 13 timeline css content.
- [`14-dialogs.css`](14-dialogs.css) — Provide 14 dialogs css content.
- [`15-actions.css`](15-actions.css) — Provide 15 actions css content.
- [`16-command-palette.css`](16-command-palette.css) — Provide 16 command palette css content.
- [`17-workspace-surfaces.css`](17-workspace-surfaces.css) — Provide 17 workspace surfaces css content.
- [`18-surface-controls.css`](18-surface-controls.css) — Provide 18 surface controls css content.
- [`19-control-specimens.css`](19-control-specimens.css) — Provide 19 control specimens css content.
- [`20-dock-groups.css`](20-dock-groups.css) — Provide 20 dock groups css content.
- [`21-panel-docking.css`](21-panel-docking.css) — Provide 21 panel docking css content.
- [`22-dock-chrome.css`](22-dock-chrome.css) — Provide 22 dock chrome css content.
- [`23-responsive-docks.css`](23-responsive-docks.css) — Provide 23 responsive docks css content.
- [`24-density.css`](24-density.css) — Provide 24 density css content.
- [`25-mock-fidelity.css`](25-mock-fidelity.css) — Provide 25 mock fidelity css content.
- [`26-edit-workspace.css`](26-edit-workspace.css) — Provide 26 edit workspace css content.
- [`27-section-row.css`](27-section-row.css) — Provide 27 section row css content.
- [`28-foundation.css`](28-foundation.css) — Provide 28 foundation css content.
- [`29-tokens.css`](29-tokens.css) — Provide 29 tokens css content.
- [`30-chrome.css`](30-chrome.css) — Provide 30 chrome css content.
- [`31-panels.css`](31-panels.css) — Provide 31 panels css content.
- [`32-steps.css`](32-steps.css) — Provide 32 steps css content.
- [`33-sidebars.css`](33-sidebars.css) — Provide 33 sidebars css content.
- [`34-timeline.css`](34-timeline.css) — Provide 34 timeline css content.
- [`35-dock-grid.css`](35-dock-grid.css) — Provide 35 dock grid css content.
- [`36-responsive.css`](36-responsive.css) — Provide 36 responsive css content.
- [`37-graph-workspace.css`](37-graph-workspace.css) — Provide 37 graph workspace css content.
- [`37-surfaces.css`](37-surfaces.css) — Provide 37 surfaces css content.
- [`38-live-target.css`](38-live-target.css) — Provide 38 live target css content.
- [`39-settings.css`](39-settings.css) — Provide 39 settings css content.
- [`40-timeline-clock.css`](40-timeline-clock.css) — Provide 40 timeline clock css content.
- [`41-panel-modes.css`](41-panel-modes.css) — Provide 41 panel modes css content.
- [`42-flow-bar.css`](42-flow-bar.css) — The Flow panel toolbar: step count, Duplicate, Remove and Add action.
- [`43-selectors.css`](43-selectors.css) — Selectors list, selector inspector and the numbered live match boxes.
- [`44-run-status.css`](44-run-status.css) — The latest run on a step: row badge and the "Last run" section.
- [`45-condition-field.css`](45-condition-field.css) — The condition field: token colours, pills, suggestions and issues.
- [`46-project-bar.css`](46-project-bar.css) — The top bar's project controls and their three responsive tiers.
- [`47-project-dialogs.css`](47-project-dialogs.css) — New project, name, unsaved-changes and gallery dialogs.

### Subdirectories

No subdirectories.

<!-- exactus:inventory:end -->
